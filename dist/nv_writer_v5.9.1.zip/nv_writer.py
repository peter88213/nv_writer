"""A "distraction free editor mode" plugin for novelibre.

Requires Python 3.7+
Copyright (c) 2025-2026 Peter Triesberger
For further information see https://github.com/peter88213/nv_writer
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_writer',
        LOCALE_PATH, languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def ready_to_close(self):
        return True

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from tkinter import font as tkFont


prefs = {}

BULLET = '* '
COMMENT_PREFIX = 'cmId'
FEATURE = _('Write in distraction free mode')

RESOLUTIONS = [
    (600, 800,),
    (720, 960,),
    (768, 1024,),
    (864, 1152,),
    (900, 1200,),
    (1080, 1440,),
    (1152, 1536,),
    (1200, 1600,),
    (1440, 1920,),
    (1600, 2133,),
]
MIN_HEIGHT, MIN_WIDTH = RESOLUTIONS[0]
DEFAULT_HEIGHT, DEFAULT_WIDTH = RESOLUTIONS[0]
SCROLLBAR_WIDTH = 20
MAX_CH_PER_LINE = 80
MIN_CH_PER_LINE = 20

MIN_FONT_SIZE = 10

NOTE_MARK = '†'
NOTE_PREFIX = 'ntId'
T_CITATION = 'note-citation'
T_COMMENT = 'comment'
T_CREATOR = 'creator'
T_DATE = 'date'
T_EM = 'em'
T_H5 = 'h5'
T_H6 = 'h6'
T_H7 = 'h7'
T_H8 = 'h8'
T_H9 = 'h9'
T_LI = 'li'
T_NOTE = 'note'
T_SPAN = 'span'
T_STRONG = 'strong'
T_UL = 'ul'

HEADING_TAGS = (T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_TAGS = ('p', T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_NESTING_TAGS = (T_COMMENT, T_NOTE)
EMPHASIZING_TAGS = (T_EM, T_STRONG)

FONTS = [
    'Consolas',  # available on Windows
    'DejaVu Sans Mono',  # usually bundled with LibreOffice
    'Liberation Mono',
    'Courier',  # fallback, if none of the above is installed
]
INSTALLED_FONTS = tkFont.families()
for editorFont in FONTS:
    if editorFont in INSTALLED_FONTS:
        break

DEFAULT_FONT = editorFont

PRJ_CONFIG_FILE = 'nv_writer.ini'
RECENT = 'RECENT'
RECENT_SECTION = 'section_ID'
RECENT_POSITION = 'position'


def check_editor_settings(window):

    passed = True
    window.update_idletasks()
    resolutionIndex = int(prefs['resolution_index'])
    if resolutionIndex >= len(RESOLUTIONS):
        prefs['resolution_index'] = resolutionIndex = len(RESOLUTIONS) - 1
        passed = False
    elif resolutionIndex < 0:
        prefs['resolution_index'] = resolutionIndex = 0
        passed = False

    height, width = RESOLUTIONS[resolutionIndex]

    screenheight = window.winfo_screenheight()
    while height > screenheight:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    screenwidth = window.winfo_screenwidth()
    while width > screenwidth:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    if not prefs['font_name'] in INSTALLED_FONTS:
        prefs['font_name'] = DEFAULT_FONT

    return passed
from tkinter import ttk

from abc import abstractmethod
import platform



class ModalDialog(tk.Toplevel):
    OFFSET = 300
    RESIZABLE = False

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        if not self.RESIZABLE:
            self.withdraw()

            self.wm_resizable(False, False)
            if platform.system() == 'Windows':
                self.attributes('-toolwindow', True)
            self.update()
            self.deiconify()
        self.wait_visibility()
        self.grab_set()
        self.focus()
        self.wm_attributes('-topmost', True)




class GenericKeys:

    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    CAPITALIZE = ('<Control-C>', f'{_("Ctrl")}-{_("Shift")}-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CLONE_SECTION = ('<Control-u>', f'{_("Ctrl")}-U')
    COMMENT = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    CREATE_SECTION = ('<Control-n>', f'{_("Ctrl")}-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DECREASE_SIZE = ('<Control-minus>', f'{_("Ctrl")}--')
    END_WRITING_MODE = ('<F11>', 'F11')
    INCREASE_SIZE = ('<Control-plus>', f'{_("Ctrl")}-+')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    LOWER_CASE = ('<Control-Y>', f'{_("Ctrl")}-{_("Shift")}-Y')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_OPTIONS_HELP = ('<F1>', 'F1')
    OPEN_HELP = ('<Control-F1>', f'{_("Ctrl")}-F1')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SAVE = ('<Control-s>', f'{_("Ctrl")}-S')
    SPLIT_SECTION = ('<Control-l>', f'{_("Ctrl")}-L')
    START_EDITOR = ('<F11>', 'F11')
    TOGGLE_CASE = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    TOGGLE_FOOTER_BAR = ('<F3>', 'F3')
    TOGGLE_HELP = ('<F1>', 'F1')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')
    UPPER_CASE = ('<Control-X>', f'{_("Ctrl")}-{_("Shift")}-X')


class LinuxKeys(GenericKeys):

    INCREASE_SIZE_KP = ('<Control-KP_Add>', f'{_("Ctrl")}-+')
    DECREASE_SIZE_KP = ('<Control-KP_Subtract>', f'{_("Ctrl")}--')
    PREVIOUS_KP = ('<Control-KP_Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    NEXT_KP = ('<Control-KP_Next>', f'{_("Ctrl")}-{_("PgDn")}')


class MacKeys(GenericKeys):

    BOLD = ('<Command-b>', 'Cmd-B')
    CAPITALIZE = ('<Command-C>', f'Cmd-{_("Shift")}-C')
    CLONE_SECTION = ('<Command-u>', 'Cmd-U')
    COMMENT = ('<Command-Option-c>', 'Cmd-Option-C')
    CREATE_SECTION = ('<Command-n>', 'Cmd-N')
    DECREASE_SIZE = ('<Command-minus>', 'Cmd--')
    INCREASE_SIZE = ('<Command-plus>', 'Cmd-+')
    ITALIC = ('<Command-i>', 'Cmd-I')
    LOWER_CASE = ('<Command-Y>', f'Cmd-{_("Shift")}-Y')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    OPEN_HELP = ('<Command-F1>', 'Cmd-F1')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SAVE = ('<Command-s>', 'Cmd-S')
    SPLIT_SECTION = ('<Command-l>', 'Cmd-L')
    START_EDITOR = ('<Command-w>', 'Cmd-W')
    TOGGLE_CASE = ('<Control-S>', f'Cmd-{_("Shift")}-S')
    UPPER_CASE = ('<Command-X>', f'Cmd-{_("Shift")}-X')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = LinuxKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()


from tkinter import ttk



class ThemePreview(ttk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        uiSize = 10
        wsSize = 12

        self._statusBar = tk.Label(
            self,
            text=_('Status'),
            font=(prefs['font_name'], uiSize)
        )
        self._statusBar.pack(
            fill='x',
        )

        self._textFrame = tk.Frame(
            self,
            padx=15,
            pady=15,
        )

        self._regularText = tk.Label(
            self._textFrame,
            text=_('Regular text'),
            font=(prefs['font_name'], wsSize),
        )
        self._regularText.pack(
            anchor='w',
            pady=3,
        )

        self._emphasizedText = tk.Label(
            self._textFrame,
            text=_('Emphasis'),
            font=(prefs['font_name'], wsSize, 'italic'),
        )
        self._emphasizedText.pack(
            anchor='w',
            pady=3,
        )

        self._strongText = tk.Label(
            self._textFrame,
            text=_('Strong emphasis'),
            font=(prefs['font_name'], wsSize, 'bold'),
        )
        self._strongText.pack(
            anchor='w',
            pady=3,
        )

        self._invertedText = tk.Label(
            self._textFrame,
            text=_('Comment'),
            font=(prefs['font_name'], wsSize),
        )
        self._invertedText.pack(
            anchor='w',
            pady=3,
        )

        self.pack(
            anchor='n',
            padx=5,
            pady=5,
            fill='x',
            side='left',
        )
        self._textFrame.pack(fill='x')

        self._footer = tk.Frame(self)
        self._footer.pack(
            fill='x',
        )
        self._button = tk.Label(
            self._footer,
            text=_('Command'),
            font=(prefs['font_name'], uiSize)
        )
        self._button.pack(
            padx=10,
            fill='x',
        )

        self._shortcut = tk.Label(
            self._footer,
            text=_('Key shortcut'),
            font=(prefs['font_name'], uiSize)
        )
        self._shortcut.pack(
            fill='x',
        )

    def configure_display(self, colors):
        self._textFrame.configure(
            bg=colors['color_bg'],
        )
        self._statusBar.configure(
            fg=colors['color_status_fg'],
            bg=colors['color_status_bg'],
        )
        self._regularText.configure(
            fg=colors['color_fg'],
            bg=colors['color_bg'],
        )
        self._emphasizedText.configure(
            fg=colors['color_em'],
            bg=colors['color_bg'],
        )
        self._strongText.configure(
            fg=colors['color_strong'],
            bg=colors['color_bg'],
        )
        self._invertedText.configure(
            fg=colors['color_bg'],
            bg=colors['color_fg'],
        )
        self._footer.configure(
            bg=colors['color_bg'],
        )
        self._button.configure(
            fg=colors['color_button_fg'],
            bg=colors['color_button_bg'],
        )
        self._shortcut.configure(
            fg=colors['color_shortcut'],
            bg=colors['color_bg'],
        )


class OptionsDialog(ModalDialog):
    OFFSET = 0
    HELP_PAGE = 'nv_writer/options.html'

    BLACK = '#000000'
    CRT_BG = '#262626'
    CRT_WHITE_LO = '#b3b3b3'
    CRT_WHITE_HI = '#d9d9d9'
    CRT_GREEN_LO = '#00cd00'
    CRT_GREEN_HI = '#00ee00'
    CRT_AMBER_LO = '#ee9a00'
    CRT_AMBER_HI = '#ffa500'
    EGA_BLUE = '#0000aa'
    EGA_CYAN = '#00aaaa'
    EGA_RED = '#aa0000'
    EGA_GRAY = '#aaaaaa'
    EGA_GREEN = '#00aa00'
    EGA_BRIGHT_CYAN = '#55ffff'
    EGA_BRIGHT_RED = '#ff5555'
    EGA_BRIGHT_YELLOW = '#ffff55'
    RED = '#ff0000'
    WHITE = '#ffffff'
    YELLOW = '#ffff00'

    THEMES = {
        _('White'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_WHITE_LO,
            color_em=CRT_WHITE_HI,
            color_strong=CRT_WHITE_HI,
            color_notes=RED,
            color_status_bg=CRT_WHITE_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_WHITE_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_WHITE_HI,
        ),
        _('Green'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_GREEN_LO,
            color_em=CRT_GREEN_HI,
            color_strong=CRT_GREEN_HI,
            color_notes=YELLOW,
            color_status_bg=CRT_GREEN_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_GREEN_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_GREEN_HI,
        ),
        _('Amber'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_AMBER_LO,
            color_em=CRT_AMBER_HI,
            color_strong=CRT_AMBER_HI,
            color_notes=YELLOW,
            color_status_bg=CRT_AMBER_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_AMBER_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_AMBER_HI,
        ),
        f"{_('Contrast')} 1": dict(
            color_bg=BLACK,
            color_fg=WHITE,
            color_em=WHITE,
            color_strong=WHITE,
            color_notes=RED,
            color_status_bg=WHITE,
            color_status_fg=BLACK,
            color_button_bg=WHITE,
            color_button_fg=BLACK,
            color_shortcut=WHITE,
        ),
        f"{_('Contrast')} 2": dict(
            color_bg=WHITE,
            color_fg=BLACK,
            color_em=BLACK,
            color_strong=BLACK,
            color_notes=RED,
            color_status_bg=BLACK,
            color_status_fg=WHITE,
            color_button_bg=BLACK,
            color_button_fg=WHITE,
            color_shortcut=BLACK,
        ),
        _('Paper'): dict(
            color_bg='#fffaf0',
            color_fg='#1a1a1a',
            color_em='#1a1a1a',
            color_strong=BLACK,
            color_notes=RED,
            color_status_bg='#999999',
            color_status_fg='#fffaf0',
            color_button_bg='#999999',
            color_button_fg='#fffaf0',
            color_shortcut=BLACK,
        ),
        'Perfect5': dict(
            color_bg=EGA_BLUE,
            color_fg=EGA_GRAY,
            color_em=EGA_BRIGHT_YELLOW,
            color_strong=WHITE,
            color_notes=EGA_BRIGHT_RED,
            color_status_bg=EGA_GRAY,
            color_status_fg=BLACK,
            color_button_bg=EGA_GRAY,
            color_button_fg=BLACK,
            color_shortcut=WHITE,
        ),
        'Soft5': dict(
            color_bg=EGA_BLUE,
            color_fg=EGA_GRAY,
            color_em=EGA_BRIGHT_CYAN,
            color_strong=WHITE,
            color_notes=EGA_BRIGHT_RED,
            color_status_bg=EGA_CYAN,
            color_status_fg=BLACK,
            color_button_bg=EGA_GRAY,
            color_button_fg=BLACK,
            color_shortcut=EGA_BRIGHT_CYAN,
        ),
        'Star3': dict(
            color_bg=EGA_CYAN,
            color_fg=BLACK,
            color_em=EGA_BRIGHT_CYAN,
            color_strong=EGA_BRIGHT_CYAN,
            color_notes=WHITE,
            color_status_bg=BLACK,
            color_status_fg=EGA_BRIGHT_CYAN,
            color_button_bg=EGA_RED,
            color_button_fg=WHITE,
            color_shortcut=WHITE,
        ),
        'Star7': dict(
            color_bg=BLACK,
            color_fg='#00cdcd',
            color_em='#d9d9d9',
            color_strong='#a6a6a6',
            color_notes=RED,
            color_status_bg='#00cd00',
            color_status_fg=BLACK,
            color_button_bg='#00eeee',
            color_button_fg=BLACK,
            color_shortcut='#00eeee',
        ),
    }

    def __init__(self, view, controller, icon, **kw):

        super().__init__(view, **kw)
        self._ctrl = controller

        self.title(_('Distraction-free writing plugin Options'))
        if icon:
            self.iconphoto(False, icon)

        def on_quit(event=None):
            change_cpl(event)
            change_username(event)
            change_spacing(event)
            self.destroy()

        self.protocol("WM_DELETE_WINDOW", on_quit)

        optionsFrame = ttk.Frame(self)
        optionsFrame.pack(fill='both')

        def change_ask_for_confirmation():
            prefs['ask_for_confirmation'] = askForConfirmationVar.get()

        askFrame = ttk.Frame(optionsFrame)
        askFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            askFrame,
            text=_('Apply changes')
        ).pack(padx=5, pady=5, anchor='w',)
        askForConfirmationVar = tk.BooleanVar(
            askFrame,
            value=prefs['ask_for_confirmation'],
        )
        ttk.Checkbutton(
            askFrame,
            text=_('Ask for confirmation'),
            variable=askForConfirmationVar,
            command=change_ask_for_confirmation,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        def change_live_wc():
            prefs['live_wordcount'] = liveWordcountVar.get()

        liveFrame = ttk.Frame(optionsFrame)
        liveFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            liveFrame,
            text=_('Word count')
        ).pack(padx=5, pady=5, anchor='w',)
        liveWordcountVar = tk.BooleanVar(
            liveFrame,
            value=prefs['live_wordcount'],
        )
        ttk.Checkbutton(
            liveFrame,
            text=_('Live update'),
            variable=liveWordcountVar,
            command=change_live_wc,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        def change_cpl(event):
            try:
                charactersPerLine = cplVar.get()
            except:
                pass
            else:
                if charactersPerLine < MIN_CH_PER_LINE:
                    charactersPerLine = MIN_CH_PER_LINE
                elif charactersPerLine > MAX_CH_PER_LINE:
                    charactersPerLine = MAX_CH_PER_LINE
                prefs['characters_per_line'] = charactersPerLine
            cplVar.set(prefs['characters_per_line'])

        cplFrame = ttk.Frame(optionsFrame)
        cplFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            cplFrame,
            text=_('Characters per line'),
        ).pack(padx=5, pady=5, anchor='w',)
        cplVar = tk.IntVar(
            value=prefs['characters_per_line']
        )
        cplEntry = ttk.Entry(
            cplFrame,
            textvariable=cplVar,
        )
        cplEntry.pack(padx=5, pady=5, anchor='w',)
        cplEntry.bind('<FocusOut>', change_cpl)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        def change_spacing(event):
            try:
                prefs['line_height'] = lineHeightVar.get()
            except:
                pass
            try:
                prefs['para_spacing'] = paraSpacingVar.get()
            except:
                pass

        spacingFrame = ttk.Frame(optionsFrame)
        spacingFrame.pack(side='left', padx=20, pady=10,)

        lineHeightVar = tk.DoubleVar(
            value=prefs['line_height'],
        )
        tk.Scale(
            spacingFrame,
            label=_('Line height'),
            orient='horizontal',
            length=200,
            variable=lineHeightVar,
            resolution=0.1,
            from_=1.0,
            to=2.0,
        ).pack(pady=10)

        paraSpacingVar = tk.DoubleVar(
            value=prefs['para_spacing'],
        )
        tk.Scale(
            spacingFrame,
            label=_('Paragraph spacing (lines)'),
            orient='horizontal',
            length=200,
            variable=paraSpacingVar,
            resolution=0.1,
            from_=0.0,
            to=1.0,
        ).pack(pady=10)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        def change_username(event):
            try:
                username = usernameVar.get()
            except:
                pass
            else:
                prefs['username'] = username
            usernameVar.set(prefs['username'])

        usernameFrame = ttk.Frame(optionsFrame)
        usernameFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            usernameFrame,
            text=_('Username'),
        ).pack(padx=5, pady=5, anchor='w',)
        usernameVar = tk.StringVar(
            value=prefs['username']
        )
        usernameEntry = ttk.Entry(
            usernameFrame,
            textvariable=usernameVar,
        )
        usernameEntry.pack(padx=5, pady=5, anchor='w',)

        def set_option(theme):
            for color in self.THEMES[theme]:
                prefs[color] = self.THEMES[theme][color]
            self._update_colors()

        ttk.Separator(
            self,
            orient='horizontal',
        ).pack(fill='x')

        currentSettingsFrame = ttk.Frame(self)
        currentSettingsFrame.pack(fill='both')
        ttk.Label(
            currentSettingsFrame,
            text=_('Color sets'),
        ).pack(padx=5, pady=5, anchor='w')
        self._currentSettingPreview = ThemePreview(currentSettingsFrame)
        ttk.Label(
            self._currentSettingPreview,
            text=_('Current setting'),
        ).pack(pady=5)
        self._update_colors()

        previewWindow = ttk.Frame(self)
        previewWindow.pack(fill='both')

        themesPerFrame = 5
        for i, theme in enumerate(self.THEMES):
            themeFrame = ttk.Frame(previewWindow)
            themeFrame.grid(
                row=i // themesPerFrame,
                column=i % themesPerFrame,
                padx='5',
                pady='5',
            )
            preview = ThemePreview(themeFrame)
            preview.configure_display(self.THEMES[theme])
            ttk.Button(
                preview,
                text=theme,
                command=lambda t=theme: set_option(t)
            ).pack(pady=5, fill='x',)

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        footer = tk.Frame(self)
        footer.pack(fill='x', expand=False)

        ttk.Button(
            footer,
            text=_('Close'),
            command=on_quit,
        ).pack(padx=5, pady=5, side='right')

        def open_help(event=None):
            self._ctrl.open_help(page=self.HELP_PAGE)

        ttk.Button(
            footer,
            text=_('Help'),
            command=open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_OPTIONS_HELP[0], open_help)

    def _update_colors(self):
        self._currentSettingPreview.configure_display(
            dict(
                color_bg=prefs['color_bg'],
                color_fg=prefs['color_fg'],
                color_em=prefs['color_em'],
                color_strong=prefs['color_strong'],
                color_notes=prefs['color_notes'],
                color_status_bg=prefs['color_status_bg'],
                color_status_fg=prefs['color_status_fg'],
                color_button_bg=prefs['color_button_bg'],
                color_button_fg=prefs['color_button_fg'],
                color_shortcut=prefs['color_shortcut'],
            )
        )

from pathlib import Path



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHAPTER_BOARD_SUFFFIX = '_sectioncards'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_REPORT_SUFFIX = '_grid_report'
GRID_SUFFIX = '_grid_tmp'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_LINE_BOARD_SUFFIX = '_plotcards'
PROJECTNOTES_REPORT_SUFFIX = '_projectnotes_report'
PROJECTNOTES_SUFFIX = '_projectnotes_tmp'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
STORY_STRUCT_BOARD_SUFFIX = '_stagecards'
TIMETABLE_SUFFIX = '_tt_tmp'
VIEWPOINT_BOARD_SUFFFIX = '_viewpoint_board'
XREF_SUFFIX = '_xref'

MAJOR_MARKER = _('Major Character')

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    _('Undefined'),
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done'),
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        return divider.join(elements)

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from tkinter import ttk


def make_scrollbar_style(
    troughcolor='black',
    background='grey',
):
    style = ttk.Style()
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.trough',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.thumb',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.grip',
        'from',
        'default',
    )
    style.layout(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        [(
            'CustomScrollbarStyle.Vertical.Scrollbar.trough',
            {
                'children': [
                    ('CustomScrollbarStyle.Vertical.Scrollbar.thumb',
                        {
                            'unit': '1',
                            'children': [(
                                'CustomScrollbarStyle.Vertical.Scrollbar.grip',
                                {'sticky': ''}
                            )],
                            'sticky': 'nswe'
                        }
                    )
                ],
                'sticky': 'ns'
            }
        )]
    )
    style.configure(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        troughcolor=troughcolor,
        background=background,
    )

from configparser import ConfigParser
from tkinter import font as tkFont
from tkinter import ttk

from datetime import datetime
from tkinter import font as tkFont
from tkinter import ttk



class Comment:

    def __init__(self):
        self.creator = ''
        self.date = ''
        self.text = ''

    def add_text(self, text, separator=''):
        if not self.text:
            self.text = text
        else:
            self.text = f'{self.text}{separator}{text}'

    def get_xml(self):
        text = self.text.replace('\n', '</p><p>')
        return(
            '<comment>'
            f'<creator>{self.creator}</creator>'
            f'<date>{self.date}</date>'
            f'<p>{text}</p>'
            '</comment>'
        )


from xml import sax



class Note(Comment):

    def __init__(self):
        self.noteId = ''
        self.noteClass = ''
        self.noteCitation = ''
        self.text = ''

    def get_xml(self):
        return(
            f'<note id="{self.noteId}" class="{self.noteClass}">'
            f'<note-citation>{self.noteCitation}</note-citation>'
            f'<p>{self.text}</p>'
            '</note>'
        )



class NovxParser(sax.ContentHandler):

    def __init__(self):
        super().__init__()

        self._taggedText = []

        self._tags = []

        self._spans = []

        self.comments = []

        self.notes = []

        self._list = None

        self._noteXmlTag = None

        self._commentXmlTag = None

    def feed(self, xmlString):
        self._taggedText.clear()
        self._tags.clear()
        self._spans.clear()
        self.comments.clear()
        self.notes.clear()
        self._list = False
        self._noteXmlTag = None
        self._commentXmlTag = None
        self._sectionStart = True

        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):

        if self._noteXmlTag == T_CITATION:
            self.notes[-1].noteCitation = content
            return

        if self._noteXmlTag == 'p':
            self.notes[-1].add_text(content, '\n')
            return

        if self._commentXmlTag == T_CREATOR:
            self.comments[-1].creator = content
            return

        if self._commentXmlTag == T_DATE:
            self.comments[-1].date = content
            return

        if self._commentXmlTag == 'p':
            self.comments[-1].add_text(content, '\n')
            return

        tags = []
        if self._tags:
            self._tags.reverse()
            tags.extend(self._tags)
        self._taggedText.append((content, tags))

    def endElement(self, name):
        if name == T_COMMENT:
            tags = [
                T_COMMENT,
                f'{COMMENT_PREFIX}:{len(self.comments)-1}',
            ]
            if self._tags:
                tags.extend(self._tags)
            self._taggedText.append((self.comments[-1].text, tags))
            self._commentXmlTag = None
            return

        if name == T_NOTE:
            tags = [
                T_NOTE,
                f'{NOTE_PREFIX}:{len(self.notes)-1}',
            ]
            if self._tags:
                tags.extend(self._tags)
            self._taggedText.append((NOTE_MARK, tags))
            self._noteXmlTag = None
            return

        if name in EMPHASIZING_TAGS:
            self._tags.remove(name)
            return

        if name == T_SPAN:
            self._tags.remove(self._spans.pop())
            return

        if name in PARAGRAPH_TAGS:
            if self._commentXmlTag is None and self._noteXmlTag is None:
                self._spans.clear()
                self._tags.clear()
            return

        if name == T_UL:
            self._list = False
            return

    def get_result(self, debug=False):
        if debug:
            print(self._taggedText)
        return self._taggedText

    def startElement(self, name, attrs):

        if name == T_COMMENT:
            self.comments.append(Comment())
            self._commentXmlTag = name
            return

        if self._commentXmlTag is not None:
            self._commentXmlTag = name
            return

        if name == T_NOTE:
            self.notes.append(Note())
            self._noteXmlTag = name
            self.notes[-1].noteId = attrs['id']
            self.notes[-1].noteClass = attrs['class']
            return

        if self._noteXmlTag is not None:
            self._noteXmlTag = name
            return


        attributes = []
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes.append(f'{attrKey}="{attrValue}"')

        suffix = ''

        if name == 'p':
            if self._taggedText and not self._list:
                suffix = '\n'
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)

        elif name in EMPHASIZING_TAGS:
            self._tags.append(name)

        elif name == T_SPAN:
            span = f"{name}_{'_'.join(attributes)}"
            self._spans.append(span)
            self._tags.append(span)

        elif name in HEADING_TAGS:
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)
            else:
                self._tags.append(name)
            if self._taggedText:
                suffix = '\n'

        elif name == T_LI:
            if self._sectionStart:
                self._sectionStart = False
                suffix = BULLET
            else:
                suffix = f'\n{BULLET}'

        elif name == T_UL:
            if self._taggedText:
                self._sectionStart = False
            self._list = True

        if suffix:
            self._taggedText.append((suffix, ''))
from xml import sax

import re


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



class TextParser():

    def __init__(self):
        self.comments = []

        self._commentIndex = None

        self.notes = []

        self._noteIndex = None

        self._paragraph = None

        self._xmlList = []

        self._xmlStack = []
        self._span = None
        self._format = None
        self._transferStack = []
        self._spanNames = []

    @property
    def _list(self):
        return T_UL in self._xmlStack

    def reset(self, debug=False):
        self._paragraph = False
        self._xmlList.clear()
        self._commentIndex = None
        self._noteIndex = None
        self._xmlStack.clear()
        self._transferStack.clear()
        self.debug = debug

    def parse_triple(self, key, value, __):
        if self.debug:
            print(key, value)
        if key == 'text' and value:
            self.characters(value)
        elif key == 'tagon' and value:
            self.startElement(value)
        elif key == 'tagoff' and value:
            self.endElement(value)

    def characters(self, content):

        content = sax.saxutils.escape(content)
        content = strip_illegal_characters(content)

        if self._commentIndex is not None:

            self.comments[self._commentIndex].add_text(content)
            return

        if self._noteIndex is not None:

            return

        if not self._paragraph:

            if content.startswith(BULLET):
                content = content.lstrip(BULLET)
                if not self._list:
                    self._start_xml(T_UL)
                self._start_xml(T_LI)

            elif self._list:
                self._end_xml()

            self._start_paragraph()

        if content.endswith('\n'):

            self._xmlList.append(content.rstrip('\n'))

            self._end_paragraph()

            if self._list:
                self._end_xml()
            return

        self._xmlList.append(content)

    def endElement(self, name):
        if name in EMPHASIZING_TAGS:
            self._format = None
            if self._span is not None:
                self._end_xml()
                self._end_xml()
                self._start_xml(self._span)
            else:
                self._end_xml()
            return

        if name.startswith(T_SPAN):
            self._span = None
            if self._format is not None:
                self._end_xml()
                self._end_xml()
                self._start_xml(self._format)
            else:
                self._end_xml()
            return

        if name.startswith(COMMENT_PREFIX):
            self._xmlList.append(self.comments[self._commentIndex].get_xml())
            self._commentIndex = None
            return

        if name.startswith(NOTE_PREFIX):
            self._xmlList.append(self.notes[self._noteIndex].get_xml())
            self._noteIndex = None
            return

    def get_result(self):
        while self._xmlStack:
            self._end_xml()
        return self._remove_redundant_tags(''.join(self._xmlList))

    def startElement(self, name):
        if name.startswith(COMMENT_PREFIX):
            self._commentIndex = int(name.split(':')[1])
            self.comments[self._commentIndex].text = ''
            return

        if name.startswith(NOTE_PREFIX):
            self._noteIndex = int(name.split(':')[1])
            return

        if  name.split('_')[0] in PARAGRAPH_TAGS:
            if self._list:
                self._end_xml()
            self._start_paragraph(name=name)
            return

        if not self._paragraph and name != 'sel':
            self._start_paragraph()

        if name in EMPHASIZING_TAGS:
            self._format = name
            self._start_xml(name)
            return

        if name.startswith(T_SPAN):
            self._span = name
            self._start_xml(name)
            xmlName = name.replace("_", " ")
            if not xmlName in self._spanNames:
                self._spanNames.append(xmlName)
            return

    def _end_paragraph(self):
        self._paragraph = False

        while self._xmlStack:
            tag = self._xmlStack.pop()
            if self.debug:
                print(f'* Closing {tag}')
            self._xmlList.append(f'</{tag}>')
            if not tag in PARAGRAPH_TAGS:
                self._transferStack.append(tag)
            else:
                break

    def _end_xml(self):
        if self._xmlStack:
            tag = self._xmlStack.pop()
            if self.debug:
                print(f'* Closing {tag}')
            self._xmlList.append(f'</{tag}>')

    def _remove_redundant_tags(self, text):
        for name in EMPHASIZING_TAGS:
            text = text.replace(f'</{name}><{name}>', '')
        for name in self._spanNames:
            text = text.replace(f'<{name}></{T_SPAN}>', '')
        return text

    def _start_paragraph(self, name='p'):
        self._paragraph = True

        self._start_xml(name)
        while self._transferStack:
            tag = self._transferStack.pop()
            if self.debug:
                print(f'* Opening {tag}')
            self._xmlStack.append(tag)
            self._xmlList.append(f'<{tag}>')

    def _start_xml(self, name):
        tag = name.split('_')[0]
        if self.debug:
            print(f'* Opening {tag}')
        self._xmlStack.append(tag)
        self._xmlList.append(f'<{name.replace("_", " ")}>')


class EditorBox(tk.Text):

    def __init__(
        self,
        master=None,
        vstyle=None,
        username=None,
        marginRight=0,
        **kw,
    ):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        if vstyle is not None:
            self.vbar.configure(style=vstyle)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})

        self._rightMargin = tk.Label(
            self.frame,
            bg=kw['bg'],
        )
        self._rightMargin.pack(side='right', fill='both', expand=True)
        kw['relief'] = 'flat'
        kw['highlightthickness'] = 0

        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='y', expand=False)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self._novxParser = NovxParser()
        self._textParser = TextParser()
        self._username = username or ''

        self.configure_font(kw['font'])
        self.tag_configure(
            T_COMMENT,
            background=kw['fg'],
            foreground=kw['bg'],
        )
        self.tag_configure(
            T_NOTE,
            foreground=prefs['color_notes'],
        )

        self.debug = False

    def capitalize(self):
        self._replace_selected(
            self._lower,
            modFirst=self._upper,
        )

    def clear(self):
        self.delete('1.0', 'end')

    def comment(self):
        if not self.tag_ranges('sel'):
            return False

        uncommented = False
        index = 'sel.first'
        while self.compare(index, '<=', 'sel.last'):
            if T_COMMENT in self.tag_names(index):
                self.tag_remove(T_COMMENT, index)
                for i in range(len(self._novxParser.comments)):
                    commentTag = f'{COMMENT_PREFIX}:{i}'
                    if commentTag in self.tag_names(index):
                        self.tag_remove(commentTag, index)
                        uncommented = True

            index = self.index(f'{index}+1c')
            if self.compare(index, '>=', 'end-1c'):
                break

        if uncommented:
            return False

        if not self._set_format(T_COMMENT):
            return False

        newComment = Comment()
        newComment.creator = self._username
        newComment.date = datetime.now().replace(
            microsecond=0
        ).isoformat()
        self._novxParser.comments.append(newComment)
        return self._set_format(
            f'{COMMENT_PREFIX}:{len(self._novxParser.comments)-1}'
        )

    def configure_font(self, font):
        defaultFont = tkFont.Font(
            root=self,
            font=font,
            name='font_name',
        )

        boldFont = tkFont.Font(**defaultFont.configure())
        boldFont.configure(weight='bold')
        italicFont = tkFont.Font(**defaultFont.configure())
        italicFont.configure(slant='italic')

        self.tag_configure(
            T_EM,
            font=italicFont,
            foreground=prefs['color_em'],
        )
        self.tag_configure(
            T_STRONG,
            font=boldFont,
            foreground=prefs['color_strong'],
        )

    def emphasis(self):
        return self._set_format(T_EM)

    def get_text(self, start='1.0', end='end'):
        self._textParser.reset(debug=self.debug)
        self._textParser.comments = self._novxParser.comments
        self._textParser.notes = self._novxParser.notes
        self.dump(start, end, command=self._textParser.parse_triple)
        return self._textParser.get_result()

    def plain(self):
        isModified = False
        if self.tag_ranges('sel'):
            index = 'sel.first'
            while not isModified and self.compare(index, '<=', 'sel.last'):
                tags = self.tag_names(index)
                for tag in tags:
                    if tag in EMPHASIZING_TAGS:
                        isModified = True
                        break
                index = self.index(f'{index}+1c')
                if self.compare(index, '>=', 'end-1c'):
                    break
            for tag in EMPHASIZING_TAGS:
                self.tag_remove(tag, 'sel.first', 'sel.last')
        return isModified

    def set_text(self, text):
        if text:
            self._novxParser.feed(text)
            taggedText = self._novxParser.get_result(debug=self.debug)
        else:
            taggedText = []

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index

        self.edit_reset()
        self.mark_set('insert', f'1.0')

    def strong_emphasis(self):
        return self._set_format(T_STRONG)

    def to_lowercase(self):
        self._replace_selected(self._lower)

    def to_uppercase(self):
        self._replace_selected(self._upper)

    def toggle_case(self):
        self._replace_selected(self._toggle_case)

    def _lower(self, text):
        return text.lower()

    def _replace_selected(self, modify, modFirst=None):
        if not self.tag_ranges('sel'):
            return

        modFirstWord = modFirst
        self.mark_set('insert', 'sel.first')
        index = 'sel.first'
        n = self.count('sel.first', 'sel.last')[0]
        for __ in range(n):
            character = self.get(index)
            if modFirstWord is not None:
                modifiedCharacter = modFirstWord(character)
                modFirstWord = None
            else:
                modifiedCharacter = modify(character)
            if modFirst is not None and character in (' ', '\n'):
                modFirstWord = modFirst

            nextIndex = f'{index}+{len(modifiedCharacter)}c'
            if modifiedCharacter != character:
                selTags = self.tag_names(index)
                self.delete(index)
                selFirst = self.index('insert')
                self.insert('insert', modifiedCharacter)
                selLast = self.index('insert')
                self.tag_add('sel', selFirst, selLast)
                for tag in selTags:
                    if tag != 'sel':
                        self.tag_add((tag), index)
            else:
                self.mark_set('insert', nextIndex)
            index = self.index(nextIndex)
            if self.compare(index, '>=', 'end-1c'):
                break

    def _set_format(self, newTag):
        if not self.tag_ranges('sel'):
            return False

        willModify = False
        index = 'sel.first'
        while self.compare(index, '<=', 'sel.last'):
            if not newTag in self.tag_names(index):
                willModify = True
                break

            index = self.index(f'{index}+1c')
            if self.compare(index, '>=', 'end-1c'):
                break

        if not willModify:
            return False

        firstCharTags = [newTag]
        for tag in self.tag_names('sel.first'):
            if tag in EMPHASIZING_TAGS:
                self.tag_remove(tag, 'sel.first')
            elif tag.split('_')[0] in PARAGRAPH_TAGS:
                self.tag_remove(tag, 'sel.first')
                firstCharTags.append(tag)
        for tag in firstCharTags:
            self.tag_add(tag, 'sel.first')

        for tag in EMPHASIZING_TAGS:
            self.tag_remove(tag, 'sel.first+1c', 'sel.last')
            self.tag_add(newTag, 'sel.first+1c', 'sel.last')

        return True

    def _toggle_case(self, text):
        if text.isupper():
            return text.lower()

        else:
            return text.upper()

    def _upper(self, text):
        return text.upper()



class FooterBar(tk.Frame):

    def __init__(self, parent, **kw):

        super().__init__(parent, background=prefs['color_bg'], **kw,)

        self._entries = []
        for desc, shortcut, sequence in (
            (_('New'), KEYS.CREATE_SECTION[1], '<<new_section>>',),
            (_('Split'), KEYS.SPLIT_SECTION[1], '<<split_section>>',),
            (_('Clone'), KEYS.CLONE_SECTION[1], '<<clone_section>>',),
            (_('Previous'), KEYS.PREVIOUS[1], '<<load_prev>>',),
            (_('Next'), KEYS.NEXT[1], '<<load_next>>',),
            (_('Save'), KEYS.SAVE[1], '<<save>>',),
            (_('Close'), KEYS.END_WRITING_MODE[1], '<<on_quit>>',),
        ):
            self._create_menu_entry(desc, shortcut, sequence)

    def set_font(self, fontSize):
        size = int(fontSize * 0.8)
        font = (prefs['font_name'], size)
        for descLabel, shortcutLabel in self._entries:
            descLabel.configure(font=font)
            shortcutLabel.configure(font=font)

    def _create_menu_entry(self, desc, shortcut, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        event = callback
        menuEntry = tk.Frame(
            self,
            background=prefs['color_bg'],
            padx=1,
            pady=1,
        )
        descLabel = tk.Label(
            menuEntry,
            background=prefs['color_button_bg'],
            foreground=prefs['color_button_fg'],
            text=desc,
        )
        descLabel.pack(
            fill='x',
            expand=True,
        )
        descLabel.bind('<Button-1>', event)
        shortcutLabel = tk.Label(
            menuEntry,
            background=prefs['color_bg'],
            foreground=prefs['color_shortcut'],
            text=shortcut,
        )
        shortcutLabel.pack(
            fill='x',
            expand=True,
        )
        shortcutLabel.bind('<Button-1>', event)
        menuEntry.pack(
            side='left',
            padx=4,
            pady=2,
            fill='x',
            expand=True,
        )
        self._entries.append((descLabel, shortcutLabel))



class HelpScreen(tk.Frame):
    PAD_X = 3

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=prefs['color_bg'],)

        self._frameWidth = 1
        self._outerFrame = tk.Frame(
            self,
            padx=self._frameWidth,
            pady=self._frameWidth,
            bg=prefs['color_fg'],
        )
        self._outerFrame.pack(
            fill='both',
            padx=6,
            pady=6,
        )
        self._headings = []
        self._entries = []

        leftFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        leftFrame.pack(
            side='left',
            anchor='n',
            fill='both',
        )
        innerFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        innerFrame.pack(
            side='left',
            anchor='n',
            fill='both',
            expand=True,
        )
        middleFrame = tk.Frame(
            innerFrame,
        )
        middleFrame.pack(
            anchor='n',
        )
        rightFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        rightFrame.pack(
            side='right',
            anchor='n',
            fill='both',
        )

        frame = leftFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('View'), row)
        )
        for desc, shortcut in (
            (_('Word count'), KEYS.UPDATE_WORDCOUNT[1],),
            (_('Menu on/off'), KEYS.TOGGLE_FOOTER_BAR[1],),
            (_('Help on/off'), KEYS.TOGGLE_HELP[1],),
            (_('User guide'), KEYS.OPEN_HELP[1],),
            (_('Enlarge'), KEYS.INCREASE_SIZE[1],),
            (_('Shrink'), KEYS.DECREASE_SIZE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        row += 1

        self._headings.append(
            self._create_heading(frame, _('Change case'), row)
        )
        for desc, shortcut in (
            (_('UPPERCASE'), KEYS.UPPER_CASE[1],),
            (_('lowercase'), KEYS.LOWER_CASE[1],),
            (_('Capitalize Every Word'), KEYS.CAPITALIZE[1],),
            (_('tOGGLE cASE'), KEYS.TOGGLE_CASE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        frame = middleFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('Edit'), row)
        )
        for desc, shortcut in (
            (_('Cut'), KEYS.CUT[1],),
            (_('Copy'), KEYS.COPY[1],),
            (_('Paste'), KEYS.PASTE[1],),
            (_('Swap characters'), f'{_("Ctrl")}-T'),
            (_('Delete character left'), f'{_("Ctrl")}-H'),
            (_('Delete to end of line'), f'{_("Ctrl")}-K'),
            (_('Delete character right'), f'{_("Ctrl")}-D'),
            (_('Open new line'), f'{_("Ctrl")}-O'),
            (_('Undo'), f'{_("Ctrl")}-Z'),
            (_('Redo'), f'{_("Ctrl")}-Y'),
            (_('Convert into comment'), KEYS.COMMENT[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        frame = rightFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('Format'), row)
        )
        for desc, shortcut in (
            (_('Emphasis'), KEYS.ITALIC[1],),
            (_('Strong emphasis'), KEYS.BOLD[1],),
            (_('Plain'), KEYS.PLAIN[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        row += 1

        self._headings.append(
            self._create_heading(frame, _('Section'), row)
        )
        for desc, shortcut in (
            (_('New'), KEYS.CREATE_SECTION[1],),
            (_('Split'), KEYS.SPLIT_SECTION[1],),
            (_('Clone'), KEYS.CLONE_SECTION[1],),
            (_('Previous'), KEYS.PREVIOUS[1],),
            (_('Next'), KEYS.NEXT[1],),
            (_('Save'), KEYS.SAVE[1],),
            (_('Close'), KEYS.END_WRITING_MODE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

    def _create_heading(self, parent, heading, row):

        headingLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_shortcut'],
            text=heading,
            anchor='w',
        )
        headingLabel.grid(
            row=row,
            column=0,
            columnspan=2,
            sticky="ew",
        )
        return headingLabel

    def _create_help_entry(self, parent, desc, shortcut, row):

        descLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=desc,
            anchor='w',
        )
        descLabel.grid(
            row=row,
            column=0,
            sticky="ew",
        )
        shortcutLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=shortcut,
            anchor='w',
        )
        shortcutLabel.grid(
            row=row,
            column=1,
            sticky="ew",
        )
        return descLabel, shortcutLabel

    def set_font(self, fontSize, scale):
        size = int(fontSize * 0.8)
        accFont = (prefs['font_name'], size, 'bold')
        dscFont = (prefs['font_name'], size)
        for descLabel, shortcutLabel in self._entries:
            shortcutLabel.configure(
                font=accFont,
                padx=int(self.PAD_X * scale),
            )
            descLabel.configure(
                font=dscFont,
                padx=int(self.PAD_X * scale),
            )
        hdFont = (prefs['font_name'], size, 'bold')
        for headinglabel in self._headings:
            headinglabel.configure(
                font=hdFont,
                padx=int(self.PAD_X * scale),
            )
        self._outerFrame.configure(
            padx=self._frameWidth * scale,
            pady=self._frameWidth * scale,
        )

from xml import sax



class SectionContentValidator(sax.ContentHandler):

    def validate_section(self, xmlString):
        self.text = False
        self.nestedParagraph = False
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, __):
        if not self.text and not self.nestedParagraph:
            raise RuntimeError('Section content validation failed')

    def endElement(self, name):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = False

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = False

    def startElement(self, name, __):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = True

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = True



class StatusBar(tk.Frame):

    def __init__(self, parent, model, **kw):
        super().__init__(
            parent,
            **kw,
        )
        self._mdl = model

        self._lockModificationIndicator = False

        self._wordCount = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._wordCount.pack(
            side='right',
        )

        self._modificationIndicator = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._modificationIndicator.pack(
            side='right',
        )

        self._breadcrumbs = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._breadcrumbs.pack(
            side='left',
        )

    def highlight(self):
        self.configure(background=prefs['color_status_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )

    def normal(self):
        self.configure(background=prefs['color_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_strong'],
            background=prefs['color_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_strong'],
            background=prefs['color_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_strong'],
            background=prefs['color_bg'],
        )

    def set_breadcrumbs(self, book, chapter, section):

        def shorten(text, length):
            if len(text) > length:
                return f'{text[:length - 3]}[…]'

            return text

        lengthTotal = 80
        lengthEntry = 25
        book = book or _('Untitled')
        book = shorten(book, lengthEntry)
        lengthTotal -= len(book)
        lengthEntry = lengthTotal // 2
        chapter = chapter or _('Untitled')
        chapter = shorten(chapter, lengthEntry)
        section = section or _('Untitled')
        self._breadcrumbs.configure(
            text=(f'{book} | {chapter} | {section}')
        )

    def set_font(self, fontSize):
        size = int(fontSize * 0.8)
        font = (prefs['font_name'], size)
        self._breadcrumbs.configure(font=font)
        self._modificationIndicator.configure(font=font)
        self._wordCount.configure(font=font)

    def set_modified(self, isModified):
        if isModified:
            self._modificationIndicator.configure(text=f"[{_('Modified')}]")
            self._lockModificationIndicator = False
        elif not self._lockModificationIndicator:
            self._modificationIndicator.configure(text='')

    def set_saved(self):
        self._modificationIndicator.configure(text=f"[{_('Saved')}]")
        self._lockModificationIndicator = True

    def set_wordcount(self, wcText):
        self._wordCount.configure(text=wcText)



class WriterView(tk.Toplevel):

    HELP_PAGE = 'nv_writer/operation.html'

    def __init__(
        self,
        model,
        view,
        controller,
    ):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._focus_app_window(False)

        tk.Toplevel.__init__(self, bg=prefs['color_ambient'])
        self.grab_set()
        self.focus()

        self._section = None
        self._scId = None
        self.wordCounter = self._mdl.nvService.get_word_counter()
        self._initialWc = 0
        self._actualWordCount = None

        self.attributes('-fullscreen', True)
        check_editor_settings(self)


        def get_x_sizes(height, width, fontSize):
            scale = height / DEFAULT_HEIGHT
            paddingX = round(int(prefs['padding_x']) * scale)
            textAreaWidth = width - (2 * paddingX) - SCROLLBAR_WIDTH
            font = tkFont.Font(family=prefs['font_name'], size=fontSize)
            lineLength = font.measure('0') * MAX_CH_PER_LINE
            return lineLength, textAreaWidth

        self._fontSizes = []
        fontSize = MIN_FONT_SIZE
        for height, width in RESOLUTIONS:
            lineLength, textAreaWidth = get_x_sizes(height, width, fontSize)
            while lineLength < textAreaWidth:
                fontSize += 1
                lineLength, textAreaWidth = get_x_sizes(height, width, fontSize)
            self._fontSizes.append(fontSize - 1)

        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        self._editorWindow = ttk.Frame(
            self,
            height=height,
            width=width,
        )
        self._editorWindow.pack(expand=True,)
        self._editorWindow.pack_propagate(0)
        paddingX = round(int(prefs['padding_x']) * scale)
        fontSize = self._fontSizes[resolutionIndex]

        self._statusBar = StatusBar(self._editorWindow, self._mdl)
        self._statusBar.set_font(fontSize)
        self._statusBar.pack(fill='x')

        self._helpScreen = HelpScreen(self._editorWindow)
        self._helpScreen.set_font(fontSize, scale)


        ttk.Style().configure(
            'CustomScrollbarStyle.Vertical.TScrollbar',
            troughcolor=prefs['color_bg'],
            background=prefs['color_bg'],
        )
        lineSpacing, paragraphSpacing = self._get_spacing()
        self._sectionEditor = EditorBox(
            self._editorWindow,
            vstyle='CustomScrollbarStyle.Vertical.TScrollbar',
            username=prefs['username'] or self._mdl.novel.authorName,
            wrap='word',
            undo=True,
            maxundo=-1,
            autoseparators=True,
            fg=prefs['color_fg'],
            bg=prefs['color_bg'],
            insertbackground=prefs['color_fg'],
            spacing2=round(lineSpacing * scale),
            spacing3=round(paragraphSpacing * scale),
            padx=paddingX,
            pady=round(int(prefs['padding_y']) * scale),
            width=prefs['characters_per_line'],
            font=(prefs['font_name'], fontSize),
        )
        self._sectionEditor.pack(fill='both', expand=True)

        self._footerBar = FooterBar(self._editorWindow)
        self._footerBar.set_font(fontSize)

        if prefs['show_footer_bar']:
            self._show_footer_bar()
            self._statusBar.highlight()
        else:
            self._statusBar.normal()
        if prefs['show_help_screen']:
            self._show_help_screen()

        keyBindings = [
            (KEYS.INCREASE_SIZE, self._increase_screen_size),
            (KEYS.DECREASE_SIZE, self._decrease_screen_size),
            (KEYS.PREVIOUS, self._load_prev),
            (KEYS.NEXT, self._load_next),
            (KEYS.OPEN_HELP, self._open_help),
            (KEYS.QUIT_PROGRAM, self.on_quit),
            (KEYS.END_WRITING_MODE, self.on_quit),
            (KEYS.UPDATE_WORDCOUNT, self._show_wordcount),
            (KEYS.SPLIT_SECTION, self._split_section),
            (KEYS.CREATE_SECTION, self._create_section),
            (KEYS.CLONE_SECTION, self._clone_section),
            (KEYS.COMMENT, self._comment),
            (KEYS.ITALIC, self._emphasis),
            (KEYS.BOLD, self._strong_emphasis),
            (KEYS.PLAIN, self._plain),
            (KEYS.SAVE, self._save_project),
            (KEYS.TOGGLE_FOOTER_BAR, self._toggle_display),
            (KEYS.TOGGLE_HELP, self._toggle_help),
            (KEYS.UPPER_CASE, self._to_uppercase),
            (KEYS.LOWER_CASE, self._to_lowercase),
            (KEYS.CAPITALIZE, self._capitalize),
            (KEYS.TOGGLE_CASE, self._toggle_case),
        ]
        if PLATFORM == 'ix':
            keyBindings.extend(
                [
                    (KEYS.INCREASE_SIZE_KP, self._increase_screen_size),
                    (KEYS.DECREASE_SIZE_KP, self._decrease_screen_size),
                    (KEYS.NEXT_KP, self._load_next),
                    (KEYS.PREVIOUS_KP, self._load_prev),
                ]
            )
        for key, callback in keyBindings:
            self._sectionEditor.bind(key[0], callback)

        eventBindings = (
            ('<<load_next>>', self._load_next),
            ('<<on_quit>>', self.on_quit),
            ('<<load_prev>>', self._load_prev),
            ('<<split_section>>', self._split_section),
            ('<<clone_section>>', self._clone_section),
            ('<<new_section>>', self._create_section),
            ('<<save>>', self._save_project),
        )
        for sequence, callback in eventBindings:
            self.bind(sequence, callback)

        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._set_wc_mode()
        self._askForConfirmation = prefs['ask_for_confirmation']

        self._validator = SectionContentValidator()

        fields = self._mdl.novel.fields
        fields.pop('writer-last-position', None)
        self._mdl.novel.fields = fields

        prjDir, __ = os.path.split(self._mdl.prjFile.filePath)
        self.prjConfigFile = os.path.join(prjDir, PRJ_CONFIG_FILE)
        prjConfig = ConfigParser()
        prjConfig.read(self.prjConfigFile)
        try:
            recent = prjConfig[RECENT]
        except:
            lastScId = lastCursorPos = None
        else:
            lastScId = recent.get(RECENT_SECTION, None)
            lastCursorPos = recent.get(RECENT_POSITION, None)
            if not self._is_editable(lastScId):
                lastScId = lastCursorPos = None

        scId = self._ui.selectedNode
        cursorPos = '1.0'
        if self._is_editable(scId):
            if scId == lastScId:
                cursorPos = lastCursorPos
        elif lastScId is not None:
            scId = lastScId
            cursorPos = lastCursorPos
        else:
            scId = self._get_first_editable_section()
            if scId is None:
                self.on_quit()
                return

        self._load_section(scId, cursorPos=cursorPos)

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        prjConfig = ConfigParser()
        prjConfig.add_section(RECENT)
        prjConfig.set(RECENT, RECENT_SECTION, self._scId)
        prjConfig.set(
            RECENT,
            RECENT_POSITION,
            self._sectionEditor.index('insert'),
        )
        with open(self.prjConfigFile, 'w') as f:
            prjConfig.write(f)

        self._focus_app_window(True)
        self.destroy()

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        sectionText = self._get_edited_section_content()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._section.sectionContent = sectionText

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._get_edited_section_content()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                result = self._confirm(message=_('Apply section changes?'))
                if result is None:
                    return False

                if result:
                    self._section.sectionContent = sectionText
        return True

    def _capitalize(self, event=None):
        self._sectionEditor.capitalize()
        return 'break'

    def _comment(self, event=None):
        self._sectionEditor.comment()
        return 'break'

    def _confirm(self, message):
        if self._askForConfirmation:
            return self._ui.ask_yes_no_cancel(
                message=message, title=FEATURE, parent=self
            )
        else:
            return True

    def _clone_section(self, event=None):
        self._apply_changes()
        self._mdl.clone_section(self._scId)

    def _create_section(self, event=None):
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        self._askForConfirmation = False
        return newId

    def _decrease_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex > 0:
            resolutionIndex -= 1
            prefs['resolution_index'] = resolutionIndex
            self._reconfigure_screen()

    def _emergency_exit(self, message='Conversion error', detail=''):
        self._focus_app_window(True)
        self.destroy()
        self._ui.show_error(
            message=message,
            detail=(
                'Distraction-free mode aborted '
                'in order not to cause damage to your project. '
                'You can ignore the following "Unexpected Error" message '
                'and continue without distraction-free mode.'
                f'{detail}'
            ),
            title='nv_writer debug message',
        )
        raise UserWarning('nv_writer aborted to prevent damage.')

    def _emphasis(self, event=None):
        if self._sectionEditor.emphasis():
            self._statusBar.set_modified(True)
        return 'break'

    def _focus_app_window(self, giveFocus):
        if giveFocus:
            if PLATFORM == 'win':
                self._ui.root.deiconify()
            self._ui.root.lift()
        else:
            if PLATFORM == 'win':
                self._ui.root.iconify()

    def _freeze_wordcount(self, event=None):
        self._statusBar.set_wordcount(
            f'{KEYS.UPDATE_WORDCOUNT[1]}: {_("Count words")}'
        )

    def _get_edited_section_content(self):
        try:
            sectionText = self._sectionEditor.get_text()
            self._validator.validate_section(sectionText)
        except:
            savedText = self._sectionEditor.get('1.0', 'end')
            emergencyFile = f'{self._mdl.prjFile.filePath}_{self._scId}.txt'
            with open(emergencyFile, 'w', encoding='utf-8') as f:
                f.write(savedText)
            self._emergency_exit(
                detail=(
                    '\n\nThe edited section is saved as plain text in '
                    f'"{emergencyFile}".'
                ),
            )
        else:
            return sectionText

    def _get_first_editable_section(self):
        result = None
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            for scId in self._mdl.novel.tree.get_children(chId):
                if self._is_editable(scId):
                    result = scId
                    break
            if result is not None:
                break
        return result

    def _get_spacing(self):
        CHARACTER_HEIGHT = 20
        lineHeight = CHARACTER_HEIGHT * float(prefs['line_height'])
        lineSpacing = lineHeight - CHARACTER_HEIGHT
        paragraphSpacing = lineSpacing + (
            lineHeight * float(prefs['para_spacing'])
        )
        return lineSpacing, paragraphSpacing

    def _hide_help_screen(self, event=None):
        self._helpScreen.pack_forget()
        prefs['show_help_screen'] = False
        return 'break'

    def _hide_footer_bar(self, event=None):
        self._footerBar.pack_forget()
        prefs['show_footer_bar'] = False
        return 'break'

    def _increase_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex < len(RESOLUTIONS) - 1:
            resolutionIndex += 1
            prefs['resolution_index'] = resolutionIndex
            if check_editor_settings(self):
                self._reconfigure_screen()

    def _is_editable(self, scId):
        if not scId in self._mdl.novel.sections:
            return False

        return self._mdl.novel.sections[scId].scType == 0

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        while nextNode and not self._is_editable(nextNode):
            nextNode = self._ui.tv.next_node(nextNode)
        if nextNode:
            self._load_section(nextNode)

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        while prevNode and not self._is_editable(prevNode):
            prevNode = self._ui.tv.prev_node(prevNode)
        if prevNode:
            self._load_section(prevNode)

    def _load_section(self, scId, cursorPos='1.0'):
        self._sectionEditor.unbind("<<Modified>>")
        self._ui.tv.go_to_node(scId)
        self._section = self._mdl.novel.sections[scId]
        self._scId = scId
        self._sectionEditor.clear()
        try:
            msg = 'Cannot load text.'
            self._sectionEditor.set_text(self._section.sectionContent)
            msg = 'Validation error.'
            self._validator.validate_section(self._sectionEditor.get_text())
        except:
            self._emergency_exit(message=msg)

        try:
            self._sectionEditor.mark_set('insert', cursorPos)
            self._sectionEditor.see('insert')
        except:
            pass

        chId = self._mdl.novel.tree.parent(scId)

        self._statusBar.set_breadcrumbs(
            self._mdl.novel.title,
            self._mdl.novel.chapters[chId].title,
            self._section.title
        )
        self._initialWc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        self._show_wordcount(wc=self._initialWc)
        self._reset_modified_flag()
        self._sectionEditor.bind(
            "<<Modified>>",
            self._update_modified_flag
        )
        self._askForConfirmation = prefs['ask_for_confirmation']
        self._sectionEditor.focus()

    def _open_help(self, event=None):
        self._ctrl.open_help(page=self.HELP_PAGE)
        return 'break'

    def _plain(self, event=None):
        if self._sectionEditor.plain():
            self._statusBar.set_modified(True)
        return 'break'

    def _reconfigure_screen(self):
        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        paddingX = round(int(prefs['padding_x']) * scale)
        fontSize = self._fontSizes[resolutionIndex]
        self._statusBar.set_font(fontSize)
        self._helpScreen.set_font(fontSize, scale)
        self._footerBar.set_font(fontSize)
        self._editorWindow.configure(
            height=height,
            width=width,
        )
        lineSpacing, paragraphSpacing = self._get_spacing()
        self._sectionEditor.configure(
            spacing2=round(lineSpacing * scale),
            spacing3=round(paragraphSpacing * scale),
            padx=paddingX,
            pady=round(int(prefs['padding_y']) * scale),
            font=(prefs['font_name'], fontSize,),
        )
        self._sectionEditor.configure_font((prefs['font_name'], fontSize,))

    def _reset_modified_flag(self, event=None):
        self._statusBar.set_modified(False)
        self._sectionEditor.edit_modified(False)

    def _save_project(self, event=None):
        self._sectionEditor.edit_modified(False)
        self._apply_changes()
        self._ctrl.save_project()
        self._statusBar.set_saved()

    def _set_wc_mode(self):
        if prefs['live_wordcount']:
            self.bind('<KeyRelease>', self._show_wordcount)
            self.unbind('<space>')
        else:
            self.unbind('<KeyRelease>')
            self.bind('<space>', self._freeze_wordcount)

    def _show_help_screen(self, event=None):
        if self._sectionEditor.winfo_manager():
            self._sectionEditor.pack_forget()
        self._helpScreen.pack(fill='x', side='top')
        self._sectionEditor.pack(fill='both', expand=True)
        prefs['show_help_screen'] = True
        return 'break'

    def _show_footer_bar(self, event=None):
        if self._sectionEditor.winfo_manager():
            self._sectionEditor.pack_forget()
        self._footerBar.pack(fill='x', side='bottom')
        self._sectionEditor.pack(fill='both', expand=True)
        prefs['show_footer_bar'] = True
        return 'break'

    def _show_wordcount(self, event=None, wc=None):
        if wc is None:
            wc = self.wordCounter.get_word_count(
                self._sectionEditor.get('1.0', 'end')
            )
        self._actualWordCount = wc
        diff = wc - self._initialWc
        text = f'{wc} {_("words")} ({diff} {_("new")})'
        self._statusBar.set_wordcount(text)

    def _split_section(self, event=None):
        if not self._ui.ask_yes_no(
            message=_('Move the text from the cursor position to the end into a new section?'),
            title=FEATURE,
            parent=self,
        ):
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
        )
        if newId:

            newContent = self._sectionEditor.get_text(
                'insert',
                'end'
            ).strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            self._mdl.novel.sections[newId].viewpoint = (
                self._mdl.novel.sections[self._scId].viewpoint
            )

            self._load_next()
            self._askForConfirmation = False

    def _strong_emphasis(self, event=None):
        if self._sectionEditor.strong_emphasis():
            self._statusBar.set_modified(True)
        return 'break'

    def _to_lowercase(self, event=None):
        self._sectionEditor.to_lowercase()
        return 'break'

    def _to_uppercase(self, event=None):
        self._sectionEditor.to_uppercase()
        return 'break'

    def _toggle_case(self, event=None):
        self._sectionEditor.toggle_case()
        return 'break'

    def _toggle_help(self, event=None):
        if self._helpScreen.winfo_manager():
            self._hide_help_screen()
        else:
            self._show_help_screen()
        return 'break'

    def _toggle_display(self, event=None):
        if self._footerBar.winfo_manager():
            self._hide_footer_bar()
            self._statusBar.normal()
        else:
            self._show_footer_bar()
            self._statusBar.highlight()
        return 'break'

    def _update_modified_flag(self, event=None):
        if self._sectionEditor.edit_modified():
            self._statusBar.set_modified(True)
            if not prefs['live_wordcount']:
                self._freeze_wordcount()
        else:
            self._reset_modified_flag()



class WriterService(SubController):
    INI_FILENAME = 'writer.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        username='',
        characters_per_line=80,
        color_ambient='#000000',
        color_bg='#262626',
        color_button_bg='#b3b3b3',
        color_button_fg='#262626',
        color_fg='#b3b3b3',
        color_em='#d9d9d9',
        color_notes='#ff0000',
        color_shortcut='#d9d9d9',
        color_status_bg='#b3b3b3',
        color_status_fg='#262626',
        color_strong='#d9d9d9',
        font_name=DEFAULT_FONT,
        padding_x=10,
        padding_y=10,
        resolution_index=1,
        line_height=1.0,
        para_spacing=1.0,
    )
    OPTIONS = dict(
        ask_for_confirmation=True,
        live_wordcount=False,
        show_footer_bar=True,
        show_help_screen=True,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

        make_scrollbar_style()

    def on_quit(self):

        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        try:
            self.configuration.write()
        except PermissionError:
            pass

    def start_editor(self):
        if self._ctrl.isLocked:
            return

        if not self._mdl.prjFile:
            return

        if not self._mdl.prjFile.filePath:
            return

        if not self._mdl.novel.sections:
            return

        activeDocuments = self._active_documents()
        if activeDocuments:
            activeDocuments.insert(
                0,
                f"{_('Documents found that might be edited')}:"
            )
            self._ui.show_error(
                message=_('Editing not possible'),
                detail='\n- '.join(activeDocuments),
                title=FEATURE,
            )
            return

        self.writer = WriterView(self._mdl, self._ui, self._ctrl)

    def _active_documents(self):
        docTypes = {
            _('Editable manuscript'): f'{MANUSCRIPT_SUFFIX}.odt',
            _('Tagged manuscript for proofing'): f'{PROOF_SUFFIX}.odt',
        }
        activeDocs = []
        try:
            fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        except TypeError:
            pass
        else:
            for doc in docTypes:
                if os.path.isfile(f'{fileName}{docTypes[doc]}'):
                    activeDocs.append(doc)
        return activeDocs



class Plugin(PluginBase):
    VERSION = '5.9.1'
    API_VERSION = '5.63'
    DESCRIPTION = 'Distraction free editor'
    URL = 'https://github.com/peter88213/nv_writer'
    HELP_PAGE = 'nv_writer'

    DTD_MAJOR_VERSION = 1
    DTD_MINOR_VERSION = 10

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        (
            novelibreDtdMajorVersion,
            novelibreDtdMinorVersion
        ) = model.nvService.get_novx_dtd_version()
        if (
            novelibreDtdMajorVersion != self.DTD_MAJOR_VERSION or
            novelibreDtdMinorVersion > self.DTD_MINOR_VERSION
        ):
            raise RuntimeError(
                'Outdated: Current novx file version not supported.'
            )

        super().install(model, view, controller)

        self.writerService = WriterService(model, view, controller)
        self._icon = self._get_icon('writer.png')


        def start_editor(event=None):
            self.writerService.start_editor()
            return 'break'

        def open_options_dialog():
            OptionsDialog(self._ui, self._ctrl, self._icon)

        self._ui.sectionMenu.add_separator()

        label = FEATURE
        self._ui.sectionMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=start_editor,
        )
        self._ui.sectionMenu.disableOnLock.append(label)

        self._ui.sectionContextMenu.add_separator()
        self._ui.sectionContextMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=start_editor,
        )
        self._ui.sectionContextMenu.disableOnLock.append(label)

        label = _('Distraction-free writing plugin Options')
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_options_dialog,
        )

        self._add_help_menu_entry(_('Distraction-free writing plugin help'))

        self._ui.toolbar.add_separator(),
        self._ui.toolbar.new_button(
            text=FEATURE,
            image=self._icon,
            command=start_editor,
            accelerator=KEYS.START_EDITOR[1],
        ).pack(side='left')

        self._ui.root.bind(KEYS.START_EDITOR[0], start_editor)

    def on_quit(self, event=None):
        self.writerService.on_quit()

