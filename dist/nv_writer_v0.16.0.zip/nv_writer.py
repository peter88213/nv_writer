"""A "distraction free editor mode" plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_writer
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_writer',
        LOCALE_PATH, languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from tkinter import font as tkFont


prefs = {}

BULLET = '* '
COMMENT_PREFIX = 'cmId'
FEATURE = _('Write in distraction free mode')

RESOLUTIONS = [
    (600, 800,),
    (720, 960,),
    (768, 1024,),
    (864, 1152,),
    (900, 1200,),
    (1080, 1440,),
    (1152, 1536,),
    (1200, 1600,),
    (1440, 1920,),
    (1600, 2133,),
]
MIN_HEIGHT, MIN_WIDTH = RESOLUTIONS[0]
DEFAULT_HEIGHT, DEFAULT_WIDTH = RESOLUTIONS[0]

NOTE_MARK = '†'
NOTE_PREFIX = 'ntId'
T_CITATION = 'note-citation'
T_COMMENT = 'comment'
T_CREATOR = 'creator'
T_DATE = 'date'
T_EM = 'em'
T_H5 = 'h5'
T_H6 = 'h6'
T_H7 = 'h7'
T_H8 = 'h8'
T_H9 = 'h9'
T_LI = 'li'
T_NOTE = 'note'
T_SPAN = 'span'
T_STRONG = 'strong'
T_UL = 'ul'

HEADING_TAGS = (T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_TAGS = ('p', T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_NESTING_TAGS = (T_COMMENT, T_NOTE)
EMPHASIZING_TAGS = (T_EM, T_STRONG)

FONTS = [
    'DejaVu Sans Mono',  # preferred font, usually bundled with LibreOffice
    'Liberation Mono',
    'Consolas',  # available on Windows
    'Courier',  # fallback, if none of the above is installed
]
INSTALLED_FONTS = tkFont.families()
for editorFont in FONTS:
    if editorFont in INSTALLED_FONTS:
        break

DEFAULT_FONT = editorFont


def check_editor_settings(window):

    passed = True
    window.update_idletasks()
    resolutionIndex = int(prefs['resolution_index'])
    if resolutionIndex >= len(RESOLUTIONS):
        prefs['resolution_index'] = resolutionIndex = len(RESOLUTIONS) - 1
        passed = False
    elif resolutionIndex < 0:
        prefs['resolution_index'] = resolutionIndex = 0
        passed = False

    height, width = RESOLUTIONS[resolutionIndex]

    screenheight = window.winfo_screenheight()
    while height > screenheight:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    screenwidth = window.winfo_screenwidth()
    while width > screenwidth:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    if not prefs['font_family'] in INSTALLED_FONTS:
        prefs['font_family'] = DEFAULT_FONT

    return passed
import webbrowser


class NvwriterHelp:

    HELP_URL = 'https://peter88213.github.io/nv_writer/help/'

    @classmethod
    def open_help_page(cls, page='', event=None):
        webbrowser.open(f'{cls.HELP_URL}{page}')

from tkinter import ttk

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()

import platform



class GenericKeys:

    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SECTION = ('<Control-n>', f'{_("Ctrl")}-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DECREASE_SIZE = ('<Control-minus>', f'{_("Ctrl")}--')
    ESCAPE = ('<Escape>', 'Esc')
    INCREASE_SIZE = ('<Control-plus>', f'{_("Ctrl")}-+')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_HELP = ('<F1>', 'F1')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SPLIT_SECTION = ('<Control-s>', f'{_("Ctrl")}-S')
    START_EDITOR = ('<Control-w>', f'{_("Ctrl")}-W')
    TOGGLE_FOOTER_BAR = ('<F3>', 'F3')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')


class MacKeys(GenericKeys):

    BOLD = ('<Command-b>', 'Cmd-B')
    CREATE_SECTION = ('<Command-n>', 'Cmd-N')
    DECREASE_SIZE = ('<Command-minus>', 'Cmd--')
    INCREASE_SIZE = ('<Command-plus>', 'Cmd-+')
    ITALIC = ('<Command-i>', 'Cmd-I')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SPLIT_SECTION = ('<Command-s>', 'Cmd-S')
    START_EDITOR = ('<Command-w>', 'Cmd-W')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()


from tkinter import ttk



class ThemePreview(ttk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        uiSize = 10
        wsSize = 12

        self._statusBar = tk.Label(
            self,
            text=_('Status'),
            font=(prefs['font_family'], uiSize)
        )
        self._statusBar.pack(
            fill='x',
        )

        self._textFrame = tk.Frame(
            self,
            padx=15,
            pady=15,
        )

        self._regularText = tk.Label(
            self._textFrame,
            text=_('Regular text'),
            font=(prefs['font_family'], wsSize)
        )
        self._regularText.pack(
            anchor='w',
            pady=3,
        )

        self._highlightedText = tk.Label(
            self._textFrame,
            text=_('Highlighted text'),
            font=(prefs['font_family'], wsSize)
        )
        self._highlightedText.pack(
            anchor='w',
            pady=3,
        )

        self._invertedText = tk.Label(
            self._textFrame,
            text=_('Comment'),
            font=(prefs['font_family'], wsSize)
        )
        self._invertedText.pack(
            anchor='w',
            pady=3,
        )

        self.pack(
            anchor='n',
            padx=5,
            pady=5,
            fill='x',
            side='left',
        )
        self._textFrame.pack(fill='x')

        self._footer = tk.Frame(self)
        self._footer.pack(
            fill='x',
        )
        self._button = tk.Label(
            self._footer,
            text=_('Command'),
            font=(prefs['font_family'], uiSize)
        )
        self._button.pack(
            padx=10,
            fill='x',
        )

        self._shortcut = tk.Label(
            self._footer,
            text=_('Shortcut'),
            font=(prefs['font_family'], uiSize)
        )
        self._shortcut.pack(
            fill='x',
        )

    def configure_display(self, colors):
        (
            colorBg,
            colorFg,
            colorHighlight,
            colorStatusBg,
            colorStatusFg,
            colorButtonBg,
            colorButtonFg,
            colorShortcut,
        ) = colors
        self._textFrame.configure(
            bg=colorBg,
        )
        self._statusBar.configure(
            fg=colorStatusFg,
            bg=colorStatusBg,
        )
        self._regularText.configure(
            fg=colorFg,
            bg=colorBg,
        )
        self._highlightedText.configure(
            fg=colorHighlight,
            bg=colorBg,
        )
        self._invertedText.configure(
            fg=colorBg,
            bg=colorFg,
        )
        self._footer.configure(
            bg=colorBg,
        )
        self._button.configure(
            fg=colorButtonFg,
            bg=colorButtonBg,
        )
        self._shortcut.configure(
            fg=colorShortcut,
            bg=colorBg,
        )


class OptionsDialog(ModalDialog):

    COLORS_WHITE = (
        'gray20',
        'gray70',
        'white',
        'gray70',
        'gray20',
        'gray70',
        'gray20',
        'white',
    )
    COLORS_GREEN = (
        'gray20',
        'green3',
        'green2',
        'green3',
        'gray20',
        'green3',
        'gray20',
        'green2',
    )
    COLORS_AMBER = (
        'gray20',
        'gold3',
        'gold',
        'gold3',
        'gray20',
        'gold3',
        'gray20',
        'gold',
    )
    COLORS_BLUE = (
        'navy',
        'gray60',
        'yellow',
        'gray60',
        'black',
        'gray60',
        'black',
        'white',
    )
    COLORS_TURQUOISE = (
        'turquoise4',
        'black',
        'cyan',
        'black',
        'cyan',
        'firebrick',
        'white',
        'white',
    )
    COLORS_PAPER = (
        'floral white',
        'gray30',
        'black',
        'gray60',
        'floral white',
        'gray60',
        'floral white',
        'gray60',
    )

    def __init__(self, view, icon, **kw):
        super().__init__(view, **kw)

        self.title(_('Distraction-free writing plugin Options'))
        self.iconphoto(False, icon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
        )
        optionsFrame = ttk.Frame(window)
        optionsFrame.pack(fill='both')

        askFrame = ttk.Frame(optionsFrame)
        askFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            askFrame,
            text=_('Apply changes')
        ).pack(padx=5, pady=5, anchor='w',)
        self._askForConfirmationVar = tk.BooleanVar(
            askFrame,
            value=prefs['ask_for_confirmation'],
        )
        ttk.Checkbutton(
            askFrame,
            text=_('Ask for confirmation'),
            variable=self._askForConfirmationVar,
            command=self._change_ask_for_confirmation,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(optionsFrame, orient='vertical').pack(fill='y', side='left',)

        liveFrame = ttk.Frame(optionsFrame)
        liveFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            liveFrame,
            text=_('Word count')
        ).pack(padx=5, pady=5, anchor='w',)
        self._liveWordcountVar = tk.BooleanVar(
            liveFrame,
            value=prefs['live_wordcount'],
        )
        ttk.Checkbutton(
            liveFrame,
            text=_('Live update'),
            variable=self._liveWordcountVar,
            command=self._change_live_wc,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(
            window,
            orient='horizontal',
        ).pack(fill='x')
        themesFrame = ttk.Frame(window)
        themesFrame.pack(fill='both')

        ttk.Label(
            themesFrame,
            text=_('Color sets'),
        ).pack(padx=5, pady=5, anchor='w')

        self._currentSettingPreview = ThemePreview(themesFrame)
        ttk.Label(
            self._currentSettingPreview,
            text=_('Current setting'),
        ).pack(pady=5)
        self._update_colors()

        optionWhitePreview = ThemePreview(themesFrame)
        optionWhitePreview.configure_display(self.COLORS_WHITE)
        ttk.Button(
            optionWhitePreview,
            text=_('White'),
            command=self._set_option_white
        ).pack(pady=5)

        optionGreenPreview = ThemePreview(themesFrame)
        optionGreenPreview.configure_display(self.COLORS_GREEN)
        ttk.Button(
            optionGreenPreview,
            text=_('Green'),
            command=self._set_option_green
        ).pack(pady=5)

        optionAmberPreview = ThemePreview(themesFrame)
        optionAmberPreview.configure_display(self.COLORS_AMBER)
        ttk.Button(
            optionAmberPreview,
            text=_('Amber'),
            command=self._set_option_amber
        ).pack(pady=5)

        optionBluePreview = ThemePreview(themesFrame)
        optionBluePreview.configure_display(self.COLORS_BLUE)
        ttk.Button(
            optionBluePreview,
            text=_('Blue'),
            command=self._set_option_blue
        ).pack(pady=5)

        optionTurquoisePreview = ThemePreview(themesFrame)
        optionTurquoisePreview.configure_display(self.COLORS_TURQUOISE)
        ttk.Button(
            optionTurquoisePreview,
            text=_('Turquoise'),
            command=self._set_option_turquoise
        ).pack(pady=5)

        optionPaperPreview = ThemePreview(themesFrame)
        optionPaperPreview.configure_display(self.COLORS_PAPER)
        ttk.Button(
            optionPaperPreview,
            text=_('Paper'),
            command=self._set_option_paper
        ).pack(pady=5)

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], NvwriterHelp.open_help_page)

    def _change_live_wc(self):
        prefs['live_wordcount'] = self._liveWordcountVar.get()

    def _change_ask_for_confirmation(self):
        prefs['ask_for_confirmation'] = self._askForConfirmationVar.get()

    def _change_colors(self, *args, **kwargs):
        pass

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('options.html')

    def _set_option_amber(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_AMBER
        self._update_colors()

    def _set_option_blue(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_BLUE
        self._update_colors()

    def _set_option_green(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_GREEN
        self._update_colors()

    def _set_option_paper(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_PAPER
        self._update_colors()

    def _set_option_turquoise(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_TURQUOISE
        self._update_colors()

    def _set_option_white(self, event=None):
        (
            prefs['color_bg'],
            prefs['color_fg'],
            prefs['color_highlight'],
            prefs['color_status_bg'],
            prefs['color_status_fg'],
            prefs['color_button_bg'],
            prefs['color_button_fg'],
            prefs['color_shortcut'],
        ) = self.COLORS_WHITE
        self._update_colors()

    def _update_colors(self):
        self._currentSettingPreview.configure_display(
            (
                prefs['color_bg'],
                prefs['color_fg'],
                prefs['color_highlight'],
                prefs['color_status_bg'],
                prefs['color_status_fg'],
                prefs['color_button_bg'],
                prefs['color_button_fg'],
                prefs['color_shortcut'],
            )
        )

from pathlib import Path



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from tkinter import ttk


def make_scrollbar_style(
    troughcolor='black',
    background='grey',
):
    style = ttk.Style()
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.trough',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.thumb',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.grip',
        'from',
        'default',
    )
    style.layout(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        [(
            'CustomScrollbarStyle.Vertical.Scrollbar.trough',
            {
                'children': [
                    ('CustomScrollbarStyle.Vertical.Scrollbar.thumb',
                        {
                            'unit': '1',
                            'children': [(
                                'CustomScrollbarStyle.Vertical.Scrollbar.grip',
                                {'sticky': ''}
                            )],
                            'sticky': 'nswe'
                        }
                    )
                ],
                'sticky': 'ns'
            }
        )]
    )
    style.configure(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        troughcolor=troughcolor,
        background=background,
    )

from tkinter import ttk

from tkinter import font as tkFont
from tkinter import ttk


from xml import sax



class Comment:

    def __init__(self):
        self.creator = ''
        self.date = ''
        self.text = ''

    def add_text(self, text, separator=''):
        if not self.text:
            self.text = text
        else:
            self.text = f'{self.text}{separator}{text}'

    def get_xml(self):
        text = self.text.replace('\n', '</p><p>')
        return(
            '<comment>'
            f'<creator>{self.creator}</creator>'
            f'<date>{self.date}</date>'
            f'<p>{text}</p>'
            '</comment>'
        )



class Note(Comment):

    def __init__(self):
        self.noteId = ''
        self.noteClass = ''
        self.noteCitation = ''
        self.text = ''

    def get_xml(self):
        return(
            f'<note id="{self.noteId}" class="{self.noteClass}">'
            f'<note-citation>{self.noteCitation}</note-citation>'
            f'<p>{self.text}</p>'
            '</note>'
        )



class NovxParser(sax.ContentHandler):

    def __init__(self):
        super().__init__()

        self._taggedText = []

        self._tags = []

        self._spans = []

        self.comments = []

        self.notes = []

        self._list = None

        self._noteXmlTag = None

        self._commentXmlTag = None

    def feed(self, xmlString):
        self._taggedText.clear()
        self._tags.clear()
        self._spans.clear()
        self.comments.clear()
        self.notes.clear()
        self._list = False
        self._noteXmlTag = None
        self._commentXmlTag = None
        self._sectionStart = True

        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):

        if self._noteXmlTag == T_CITATION:
            self.notes[-1].noteCitation = content
            return

        if self._noteXmlTag == 'p':
            self.notes[-1].add_text(content, '\n')
            return

        if self._commentXmlTag == T_CREATOR:
            self.comments[-1].creator = content
            return

        if self._commentXmlTag == T_DATE:
            self.comments[-1].date = content
            return

        if self._commentXmlTag == 'p':
            self.comments[-1].add_text(content, '\n')
            return

        tags = []
        if self._tags:
            self._tags.reverse()
            tags.extend(self._tags)
        self._taggedText.append((content, tags))

    def endElement(self, name):
        if name == T_COMMENT:
            tags = [
                T_COMMENT,
                f'{COMMENT_PREFIX}:{len(self.comments)-1}',
            ]
            if self._tags:
                tags.extend(self._tags)
            self._taggedText.append((self.comments[-1].text, tags))
            self._commentXmlTag = None
            return

        if name == T_NOTE:
            tag = (T_NOTE, f'{NOTE_PREFIX}:{len(self.notes)-1}')
            self._taggedText.append((NOTE_MARK, tag))
            self._noteXmlTag = None
            return

        if name in EMPHASIZING_TAGS:
            self._tags.remove(name)
            return

        if name == T_SPAN:
            self._tags.remove(self._spans.pop())
            return

        if name in PARAGRAPH_TAGS:
            if self._commentXmlTag is None:
                self._spans.clear()
                self._tags.clear()
            return

        if name == T_UL:
            self._list = False
            return

    def get_result(self, debug=False):
        if debug:
            print(self._taggedText)
        return self._taggedText

    def startElement(self, name, attrs):

        if name == T_COMMENT:
            self.comments.append(Comment())
            self._commentXmlTag = name
            return

        if self._commentXmlTag is not None:
            self._commentXmlTag = name
            return

        if name == T_NOTE:
            self.notes.append(Note())
            self._noteXmlTag = name
            self.notes[-1].noteId = attrs['id']
            self.notes[-1].noteClass = attrs['class']
            return

        if self._noteXmlTag is not None:
            self._noteXmlTag = name
            return


        attributes = []
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes.append(f'{attrKey}="{attrValue}"')

        suffix = ''

        if name == 'p':
            if self._taggedText and not self._list:
                suffix = '\n'
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)

        elif name in EMPHASIZING_TAGS:
            self._tags.append(name)

        elif name == T_SPAN:
            span = f"{name}_{'_'.join(attributes)}"
            self._spans.append(span)
            self._tags.append(span)

        elif name in HEADING_TAGS:
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)
            else:
                self._tags.append(name)
            if self._taggedText:
                suffix = '\n'

        elif name == T_LI:
            if self._sectionStart:
                self._sectionStart = False
                suffix = BULLET
            else:
                suffix = f'\n{BULLET}'

        elif name == T_UL:
            if self._taggedText:
                self._sectionStart = False
            self._list = True

        if suffix:
            self._taggedText.append((suffix, ''))
from xml.sax.saxutils import escape

import re


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



class TextParser():

    def __init__(self):
        self.comments = []

        self._commentIndex = None

        self.notes = []

        self._noteIndex = None

        self._paragraph = None
        self._heading = None

        self._xmlList = []

        self._xmlStack = []

    @property
    def _list(self):
        return T_UL in self._xmlStack

    def reset(self, debug=False):
        self._paragraph = False
        self._heading = False
        self._xmlList.clear()
        self._commentIndex = None
        self._noteIndex = None
        self._xmlStack.clear()
        self.debug = debug

    def parse_triple(self, key, value, __):
        if self.debug:
            print(key, value)
        if key == 'text' and value:
            self.characters(value)
        elif key == 'tagon' and value:
            self.startElement(value)
        elif key == 'tagoff' and value:
            self.endElement(value)

    def characters(self, content):

        content = escape(content)
        content = strip_illegal_characters(content)

        if self._commentIndex is not None:

            self.comments[self._commentIndex].add_text(content)
            return

        if self._noteIndex is not None:

            return

        if not self._paragraph:

            if content.startswith(BULLET):
                content = content.lstrip(BULLET)
                if not self._list:
                    self._startXml(T_UL)
                self._startXml(T_LI)

            elif self._list:
                self._endXml()

            self._startXml('p')
            self._paragraph = True

        if content.endswith('\n'):

            self._xmlList.append(content.rstrip('\n'))
            if not self._heading:
                self._endXml()
            else:
                self._heading = False
            self._paragraph = False

            if self._list:
                self._endXml(self.debug)
            return

        self._xmlList.append(content)

    def endElement(self, name):
        if name in EMPHASIZING_TAGS:
            self._endXml()
            return

        if name.startswith(T_SPAN):
            self._endXml()
            return

        if name.startswith(COMMENT_PREFIX):
            self._xmlList.append(self.comments[self._commentIndex].get_xml())
            self._commentIndex = None
            return

        if name.startswith(NOTE_PREFIX):
            self._xmlList.append(self.notes[self._noteIndex].get_xml())
            self._noteIndex = None
            return

        tag = self._get_heading_tag(name)
        if tag is not None:
            self._endXml()

    def get_result(self):
        while self._xmlStack:
            self._endXml()
        return ''.join(self._xmlList)

    def startElement(self, name):
        if name.startswith(COMMENT_PREFIX):
            self._commentIndex = int(name.split(':')[1])
            self.comments[self._commentIndex].text = ''
            return

        if name.startswith(NOTE_PREFIX):
            self._noteIndex = int(name.split(':')[1])
            return

        if self._is_paragraph_tag(name):
            if self._list:
                self._endXml(self.debug)
            self._startXml(name)
            self._paragraph = True
            return

        if self._get_heading_tag(name) is not None:
            if self._list:
                self._endXml(self.debug)
            self._startXml(name)
            self._paragraph = True
            self._heading = True
            return

        if not self._paragraph:
            self._startXml('p')
            self._paragraph = True

        if name in EMPHASIZING_TAGS:
            self._startXml(name)
            return

        if name.startswith(T_SPAN):
            self._startXml(name)
            return

    def _endXml(self, debug=False):
        tag = self._xmlStack.pop()
        if debug:
            print(f'* Closing {tag}')
        self._xmlList.append(f'</{tag}>')

    def _get_heading_tag(self, name):
        tag = name.split('_')[0]
        if tag in HEADING_TAGS:
            return tag
        else:
            return None

    def _is_paragraph_tag(self, name):
        if not name.startswith('p'):
            return False

        return name.split('_')[0] == 'p'

    def _startXml(self, name, debug=False):
        tag = name.split('_')[0]
        if debug:
            print(f'* Opening {tag}')
        self._xmlStack.append(tag)
        self._xmlList.append(f'<{name.replace("_", " ")}>')



class EditorBox(tk.Text):

    def __init__(
        self,
        master=None,
        vstyle=None,
        color_highlight='grey',
        **kw,
    ):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        if vstyle is not None:
            self.vbar.configure(style=vstyle)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self._novxParser = NovxParser()
        self._textParser = TextParser()

        self.configure_font(kw['font'])
        self.tag_configure(
            T_COMMENT,
            background=kw['fg'],
            foreground=kw['bg'],
        )
        self.tag_configure(
            T_NOTE,
            foreground=color_highlight,
        )

        self.debug = False

    def clear(self):
        self.delete('1.0', 'end')

    def configure_font(self, font):
        defaultFont = tkFont.Font(
            root=self,
            font=font,
            name='editor_font',
        )

        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')

        self.tag_configure(
            T_EM,
            font=italicFont,
        )
        self.tag_configure(
            T_STRONG,
            font=boldFont,
        )

    def get_text(self, start='1.0', end='end'):
        self._textParser.reset(debug=self.debug)
        self._textParser.comments = self._novxParser.comments
        self._textParser.notes = self._novxParser.notes
        self.dump(start, end, command=self._textParser.parse_triple)
        return self._textParser.get_result()

    def set_text(self, text):
        if text:
            self._novxParser.feed(text)
            taggedText = self._novxParser.get_result(debug=self.debug)
        else:
            taggedText = []

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index

        self.edit_reset()
        self.mark_set('insert', f'1.0')

    def emphasis(self, event=None):
        self._set_format(tag=T_EM)
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag=T_STRONG)
        return 'break'

    def plain(self, event=None):
        if self.tag_ranges(tk.SEL):
            for tag in EMPHASIZING_TAGS:
                self.tag_remove(tag, tk.SEL_FIRST, tk.SEL_LAST)
        return 'break'

    def _get_tags(self, start, end):
        index = start
        tags = []
        while self.compare(index, '<=', end):
            tags.extend(self.tag_names(index))
            index = self.index(f'{index}+1c')
        return set(tags)

    def _set_format(self, event=None, tag=''):
        if self.tag_ranges(tk.SEL):
            self.plain()
            self.tag_add(tag, tk.SEL_FIRST, tk.SEL_LAST)



class FooterBar(tk.Frame):

    def __init__(self, parent, **kw):
        super().__init__(
            parent,
            background=prefs['color_bg'],
            **kw,
        )

        self._entries = []

        text, accelerator = self._create_menu_entry(
            _('Create section'),
            KEYS.CREATE_SECTION[1],
            '<<new_section>>'
        )
        self._entries.append((text, accelerator))

        text, accelerator = self._create_menu_entry(
            _('Split at cursor position'),
            KEYS.SPLIT_SECTION[1],
            '<<split_section>>'
        )
        self._entries.append((text, accelerator))

        text, accelerator = self._create_menu_entry(
            _('Previous'),
            KEYS.PREVIOUS[1],
            '<<load_prev>>'
        )
        self._entries.append((text, accelerator))

        text, accelerator = self._create_menu_entry(
            _('Next'),
            KEYS.NEXT[1],
            '<<load_next>>'
        )
        self._entries.append((text, accelerator))

        text, accelerator = self._create_menu_entry(
            _('Close'),
            KEYS.QUIT_PROGRAM[1],
            '<<on_quit>>'
        )
        self._entries.append((text, accelerator))

    def _create_menu_entry(self, text, accelerator, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        event = callback
        entry = tk.Frame(
            self,
            background=prefs['color_bg'],
            padx=1,
            pady=1,
        )
        text = tk.Label(
            entry,
            background=prefs['color_button_bg'],
            foreground=prefs['color_button_fg'],
            text=text,
        )
        text.pack(
            fill='x',
            expand=True,
        )
        text.bind('<Button-1>', event)
        accelerator = tk.Label(
            entry,
            background=prefs['color_bg'],
            foreground=prefs['color_shortcut'],
            text=accelerator,
        )
        accelerator.pack(
            fill='x',
            expand=True,
        )
        accelerator.bind('<Button-1>', event)
        entry.pack(
            side='left',
            padx=4,
            pady=2,
            fill='x',
            expand=True,
        )
        return text, accelerator

    def set_font(self, scale):
        size = int(int(prefs['default_font_size']) * scale * 0.8)
        font = (prefs['font_family'], size)
        for text, accelerator in self._entries:
            text.configure(font=font)
            accelerator.configure(font=font)

from xml import sax



class SectionContentValidator(sax.ContentHandler):

    def validate_section(self, xmlString):
        self.text = False
        self.nestedParagraph = False
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, __):
        if not self.text and not self.nestedParagraph:
            raise RuntimeError('Section content validation failed')

    def endElement(self, name):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = False

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = False

    def startElement(self, name, __):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = True

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = True

import textwrap



class StatusBar(tk.Frame):

    def __init__(self, parent, model, **kw):
        super().__init__(
            parent,

            **kw,
        )
        self._mdl = model

        self._wordCount = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._wordCount.pack(
            side='right',
        )

        self._modificationIndicator = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._modificationIndicator.pack(
            side='right',
        )

        self._breadcrumbs = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._breadcrumbs.pack(
            side='left',
        )

    def normal(self):
        self.configure(background=prefs['color_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )

    def highlight(self):
        self.configure(background=prefs['color_status_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )

    def set_breadcrumbs(self, book, chapter, section):
        lengthTotal = 80
        lengthEntry = 25
        book = textwrap.shorten(book, lengthEntry)
        lengthTotal -= len(book)
        lengthEntry = lengthTotal // 2
        chapter = textwrap.shorten(chapter, lengthEntry)
        lengthTotal -= len(chapter)
        section = textwrap.shorten(section, lengthTotal)
        self._breadcrumbs.configure(
            text=(f'{book} | {chapter} | {section}')
        )

    def set_font(self, scale):
        size = int(int(prefs['default_font_size']) * scale * 0.8)
        font = (prefs['font_family'], size)
        self._breadcrumbs.configure(font=font)
        self._modificationIndicator.configure(font=font)
        self._wordCount.configure(font=font)

    def set_modified(self, isModified):
        if isModified:
            self._modificationIndicator.configure(text=_('Modified'))
        else:
            self._modificationIndicator.configure(text='')

    def set_wordcount(self, wc, diff):
        self._wordCount.configure(
            text=f'{wc} {_("words")} ({diff} {_("new")})'
        )



class WriterView(ModalDialog):

    def __init__(
        self,
        model,
        view,
        controller,
    ):
        view.root.iconify()
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        super().__init__(view, bg=prefs['color_desktop'])

        self._section = None
        self._scId = None
        self.wordCounter = self._mdl.nvService.get_word_counter()
        self._initialWc = None

        self.attributes('-fullscreen', True)
        check_editor_settings(self)

        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        self._editorWindow = ttk.Frame(
            self,
            height=height,
            width=width,
        )
        self._editorWindow.pack(expand=True,)
        self._editorWindow.pack_propagate(0)

        self._statusBar = StatusBar(self._editorWindow, self._mdl)
        self._statusBar.set_font(scale)
        self._statusBar.pack(fill='x')


        ttk.Style().configure(
            'CustomScrollbarStyle.Vertical.TScrollbar',
            troughcolor=prefs['color_bg'],
            background=prefs['color_desktop'],
        )

        self._sectionEditor = EditorBox(
            self._editorWindow,
            vstyle='CustomScrollbarStyle.Vertical.TScrollbar',
            color_highlight=prefs['color_highlight'],
            wrap='word',
            undo=True,
            maxundo=-1,
            autoseparators=True,
            fg=prefs['color_fg'],
            bg=prefs['color_bg'],
            insertbackground=prefs['color_fg'],
            spacing1=int(int(prefs['paragraph_spacing']) * scale),
            spacing2=int(int(prefs['line_spacing']) * scale),
            padx=int(int(prefs['margin_horizontal']) * scale),
            pady=int(int(prefs['margin_vertical']) * scale),
            font=(
                prefs['font_family'],
                int(int(prefs['default_font_size']) * scale),
            ),
        )
        self._sectionEditor.pack(fill='both', expand=True)

        self._footerBar = FooterBar(self._editorWindow)
        self._footerBar.set_font(scale)
        if prefs['_show_footer_bar']:
            self._show_footer_bar()
            self._statusBar.highlight()
        else:
            self._statusBar.normal()

        keyBindings = (
            (KEYS.INCREASE_SIZE, self._increase_screen_size),
            (KEYS.DECREASE_SIZE, self._decrease_screen_size),
            (KEYS.PREVIOUS, self._load_prev),
            (KEYS.NEXT, self._load_next),
            (KEYS.OPEN_HELP, self._open_help),
            (KEYS.QUIT_PROGRAM, self.on_quit),
            (KEYS.ESCAPE, self.on_quit),
            (KEYS.UPDATE_WORDCOUNT, self._show_wordcount),
            (KEYS.SPLIT_SECTION, self._split_section),
            (KEYS.CREATE_SECTION, self._create_section),
            (KEYS.TOGGLE_FOOTER_BAR, self._toggle_display)
        )
        for key, callback in keyBindings:
            self._sectionEditor.bind(key[0], callback)

        eventBindings = (
            ('<<load_next>>', self._load_next),
            ('<<on_quit>>', self.on_quit),
            ('<<load_prev>>', self._load_prev),
            ('<<split_section>>', self._split_section),
            ('<<new_section>>', self._create_section),
        )
        for sequence, callback in eventBindings:
            self.bind(sequence, callback)

        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._set_wc_mode()
        self._askForConfirmation = prefs['ask_for_confirmation']

        self._validator = SectionContentValidator()

        self._load_section(self._ui.selectedNode)
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        self._ui.root.deiconify()
        self._ui.root.lift()
        self.destroy()

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._section.sectionContent = sectionText

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                result = self._confirm(message=_('Apply section changes?'))
                if result is None:
                    return False

                if result:
                    self._section.sectionContent = sectionText
        return True

    def _confirm(self, message):
        if self._askForConfirmation:
            return self._ui.ask_yes_no_cancel(
                message=message,
                title=FEATURE,
                parent=self,
            )
        else:
            return True

    def _create_section(self, event=None):
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        self._askForConfirmation = False
        return newId

    def _decrease_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex > 0:
            resolutionIndex -= 1
            prefs['resolution_index'] = resolutionIndex
            self._reconfigure_screen()

    def _hide_footer_bar(self, event=None):
        self._footerBar.pack_forget()
        prefs['_show_footer_bar'] = False
        return 'break'

    def _increase_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex < len(RESOLUTIONS) - 1:
            resolutionIndex += 1
            prefs['resolution_index'] = resolutionIndex
            if check_editor_settings(self):
                self._reconfigure_screen()

    def _is_editable(self, scId):
        if not scId or not scId.startswith(SECTION_PREFIX):
            return False

        return self._mdl.novel.sections[scId].scType == 0

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        while nextNode and not self._is_editable(nextNode):
            nextNode = self._ui.tv.next_node(nextNode)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self._scId = nextNode
            self._load_section(self._scId)

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        while prevNode and not self._is_editable(prevNode):
            prevNode = self._ui.tv.prev_node(prevNode)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self._scId = prevNode
            self._load_section(self._scId)

    def _load_section(self, scId=None):
        self._sectionEditor.unbind("<<Modified>>")
        finished = False
        if not self._is_editable(scId):
            for chId in self._mdl.novel.tree.get_children(CH_ROOT):
                for scId in self._mdl.novel.tree.get_children(chId):
                    if self._is_editable(scId):
                        finished = True
                        break
                if finished:
                    break
        else:
            finished = True
        if not finished:
            return

        self._section = self._mdl.novel.sections[scId]
        self._sectionEditor.clear()
        try:
            self._sectionEditor.set_text(self._section.sectionContent)
            self._validator.validate_section(self._sectionEditor.get_text())
        except:
            self._ui.root.deiconify()
            self._ui.root.lift()
            self.destroy()
            self._ui.show_error(
                message='This section cannot be processed with nv_writer.',
                detail=(
                    'Distraction-free mode aborted '
                    'in order not to cause damage to your project. '
                    'You can ignore the following "Unexpected Error" message '
                    'and continue without distraction-free mode.'
                ),
                title='nv_writer debug message',
            )
            raise UserWarning('nv_writer aborted to prevent damage.')

        self._scId = scId
        chId = self._mdl.novel.tree.parent(self._scId)

        self._statusBar.set_breadcrumbs(
            self._mdl.novel.title,
            self._mdl.novel.chapters[chId].title,
            self._section.title
        )
        self._initialWc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        self._show_wordcount()
        self._reset_modified_flag()
        self._sectionEditor.bind(
            "<<Modified>>",
            self._update_modified_flag
        )
        self._askForConfirmation = prefs['ask_for_confirmation']

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('operation.html')

    def _reconfigure_screen(self):
        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        self._statusBar.set_font(scale)
        self._footerBar.set_font(scale)
        self._editorWindow.configure(
            height=height,
            width=width,
        )
        self._sectionEditor.configure(
            spacing1=int(int(prefs['paragraph_spacing']) * scale),
            spacing2=int(int(prefs['line_spacing']) * scale),
            padx=int(int(prefs['margin_horizontal']) * scale),
            pady=int(int(prefs['margin_vertical']) * scale),
            font=(
                prefs['font_family'],
                int(int(prefs['default_font_size']) * scale),
            ),
        )
        self._sectionEditor.configure_font(
            (
                prefs['font_family'],
                int(int(prefs['default_font_size']) * scale),
            ),
        )

    def _reset_modified_flag(self, event=None):
        self._statusBar.set_modified(False)
        self._sectionEditor.edit_modified(False)

    def _set_wc_mode(self):
        if prefs['live_wordcount']:
            self.bind('<KeyRelease>', self._show_wordcount)
        else:
            self.unbind('<KeyRelease>')

    def _show_footer_bar(self, event=None):
        if self._sectionEditor.winfo_manager():
            self._sectionEditor.pack_forget()
        self._footerBar.pack(fill='x', side='bottom')
        self._sectionEditor.pack(fill='both', expand=True)
        prefs['_show_footer_bar'] = True
        return 'break'

    def _show_wordcount(self, event=None):
        wc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        diff = wc - self._initialWc
        self._statusBar.set_wordcount(wc, diff)

    def _split_section(self, event=None):
        if not self._ui.ask_yes_no(
            message=_('Move the text from the cursor position to the end into a new section?'),
            title=FEATURE,
            parent=self,
        ):
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self._sectionEditor.get_text(
                'insert',
                'end'
            ).strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            self._mdl.novel.sections[newId].viewpoint = (
                self._mdl.novel.sections[self._scId].viewpoint
            )

            self._load_next()
            self._askForConfirmation = False

    def _toggle_display(self, event=None):
        if self._footerBar.winfo_manager():
            self._hide_footer_bar()
            self._statusBar.normal()
        else:
            self._show_footer_bar()
            self._statusBar.highlight()
        return 'break'

    def _update_modified_flag(self, event=None):
        if self._sectionEditor.edit_modified():
            self._statusBar.set_modified(True)
        else:
            self._reset_modified_flag()



class WriterService(SubController):
    INI_FILENAME = 'writer.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        color_bg='gray20',
        color_button_bg='gray70',
        color_button_fg='gray20',
        color_desktop='gray30',
        color_fg='gray70',
        color_highlight='white',
        color_shortcut='white',
        color_status_bg='gray70',
        color_status_fg='gray20',
        default_font_size=12,
        font_family=DEFAULT_FONT,
        line_spacing=7,
        margin_horizontal=10,
        margin_vertical=10,
        paragraph_spacing=14,
        resolution_index=1,
    )
    OPTIONS = dict(
        live_wordcount=False,
        _show_footer_bar=False,
        ask_for_confirmation=True,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

        make_scrollbar_style()

    def on_quit(self):

        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        self.configuration.write()

    def start_editor(self):
        if self._ctrl.isLocked:
            return

        if not self._mdl.prjFile:
            return

        activeDocuments = self._active_documents()
        if activeDocuments:
            activeDocuments.insert(
                0,
                f"{_('Documents found that might be edited')}:"
            )
            self._ui.show_error(
                message=_('Editing not possible'),
                detail='\n- '.join(activeDocuments),
                title=FEATURE,
            )
            return

        self.writer = WriterView(self._mdl, self._ui, self._ctrl)

    def _active_documents(self):
        docTypes = {
            _('Editable manuscript'): f'{MANUSCRIPT_SUFFIX}.odt',
            _('Tagged manuscript for proofing'): f'{PROOF_SUFFIX}.odt',
        }
        fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        activeDocs = []
        for doc in docTypes:
            if os.path.isfile(f'{fileName}{docTypes[doc]}'):
                activeDocs.append(doc)
        return activeDocs



class Plugin(PluginBase):
    VERSION = '0.16.0'
    API_VERSION = '5.52'
    DESCRIPTION = 'Distraction free editor'
    URL = 'https://github.com/peter88213/nv_writer'

    DTD_MAJOR_VERSION = 1
    DTD_MINOR_VERSION = 9

    def install(self, model, view, controller):
        """Extend the 'View' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        (
            novelibreDtdMajorVersion,
            novelibreDtdMinorVersion
        ) = model.nvService.get_novx_dtd_version()
        if (
            novelibreDtdMajorVersion != self.DTD_MAJOR_VERSION or
            novelibreDtdMinorVersion > self.DTD_MINOR_VERSION
        ):
            raise RuntimeError(
                'Outdated: Current novx file version not supported.'
            )

        super().install(model, view, controller)

        self.writerService = WriterService(model, view, controller)
        self._icon = self._get_icon('writer.png')

        self._ui.sectionMenu.add_separator()

        label = FEATURE
        self._ui.sectionMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionMenu.disableOnLock.append(label)

        self._ui.sectionContextMenu.add_separator()
        self._ui.sectionContextMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionContextMenu.disableOnLock.append(label)

        label = _('Distraction-free writing plugin Options')
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self._open_options_dialog,
        )

        label = _('Distraction-free writing plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=NvwriterHelp.open_help_page,
        )

        self._ui.root.bind(KEYS.START_EDITOR[0], self.start_editor)

    def on_quit(self, event=None):
        self.writerService.on_quit()

    def start_editor(self, event=None):
        self.writerService.start_editor()
        return 'break'

    def _open_options_dialog(self):
        OptionsDialog(self._ui, self._icon)
