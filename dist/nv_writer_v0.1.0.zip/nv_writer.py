"""A "distraction free editor mode" plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_writer
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_writer',
        LOCALE_PATH, languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

from tkinter import messagebox
from tkinter import ttk

from abc import abstractmethod

import tkinter as tk


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

import re
from tkinter import ttk



def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)

from tkinter import ttk


def make_scrollbar_styles(
    troughcolor='black',
    background='grey',
    arrowcolor='white',
):
    style = ttk.Style()

    for is_hori in (True, False):
        v = "Horizontal" if is_hori else "Vertical"
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.trough',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.thumb',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.leftarrow',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.rightarrow',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.grip',
            'from',
            'default',
        )
        style.layout(
            f'CustomScrollbarStyle.{v}.TScrollbar',
            [(f'CustomScrollbarStyle.{v}.Scrollbar.trough', {
                'children': [
                    (f'CustomScrollbarStyle.{v}.Scrollbar.thumb', {
                        'unit': '1',
                        'children': [(
                            f'CustomScrollbarStyle.{v}.Scrollbar.grip',
                            {'sticky': ''}
                        )],
                        'sticky': 'nswe'}
                     )
                ],
                'sticky': 'we' if is_hori else 'ns'}),
             ])
        style.configure(
            f'CustomScrollbarStyle.{v}.TScrollbar',
            troughcolor=troughcolor,
            background=background,
            arrowcolor=arrowcolor,
        )
    return (
        "CustomScrollbarStyle.Horizontal.TScrollbar",
        "CustomScrollbarStyle.Vertical.TScrollbar"
    )

import xml.etree.ElementTree as ET


class EditorBox(tk.Text):
    _TAGS = ('em', 'strong')
    XML_TAG = 'xmlTag'
    COLOR_XML_TAG = 'cornflower blue'

    def __init__(
        self,
        master=None,
        troughcolor='black',
        background='grey',
        **kw,
    ):
        self.frame = ttk.Frame(master)
        __, vstyle = make_scrollbar_styles(
            troughcolor=troughcolor,
            background=background,
        )
        self.vbar = ttk.Scrollbar(self.frame, style=vstyle)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self.tag_configure(self.XML_TAG,
                           foreground=self.COLOR_XML_TAG,
                           )

    def check_validity(self):
        text = strip_illegal_characters(self.get("1.0", "end"))
        xmlText = f'<a>{text}</a>'
        try:
            ET.fromstring(xmlText)
        except Exception as ex:
            issue, location = str(ex).split(':')
            lineStr = re.search(r'line ([0-9]+)', location).group(1)
            columnStr = re.search(r'column ([0-9]+)', location).group(1)
            column = int(columnStr) - 3
            self.mark_set('insert', f'{lineStr}.{column}')
            raise ValueError(f'{issue}: line {lineStr} column {column}')
            return False

        return True

    def clear(self):
        self.delete('1.0', 'end')

    def get_text(self, start='1.0', end='end'):
        text = self.get(start, end)
        text = text.strip(' \n')
        text = text.replace('\n', '')
        return strip_illegal_characters(text)

    def colorize(self, event=None):
        self.tag_remove(self.XML_TAG, '1.0', 'end')
        for i in range(int(self.index('end').split('.')[0])):
            line = self.get(f'{i}.0', f'{i}.0 lineend')
            for xmlTag in re.finditer('<.*?>', line):
                self.tag_add(
                    self.XML_TAG,
                    f'{i}.{xmlTag.start()}',
                    f'{i}.{xmlTag.end()}',
                )

    def set_text(self, text):
        startIndex = len("<p>")
        if not text:
            text = '<p></p>'
        for tag in ('p', 'h5', 'h6', 'h7', 'h8', 'h9'):
            text = text.replace(f'</{tag}>', f'</{tag}>\n')
        self.insert('end', text)
        self.edit_reset()
        self.mark_set('insert', f'1.{startIndex}')
        self.colorize()

    def emphasis(self, event=None):
        self._set_format(tag='em')
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag='strong')
        return 'break'

    def plain(self, event=None):
        self._set_format()
        return 'break'

    def new_paragraph(self, event=None):
        self.insert('insert', '</p>\n<p>')
        self.colorize()
        return 'break'

    def _convert_from_novx(self, text, textTag, update):
        self._contentParser.textTag = textTag
        self._contentParser.update = update
        self._contentParser.feed(text)
        return self._contentParser.taggedText[1:-1]

    def _set_format(self, event=None, tag=''):
        if tag:
            if self.tag_ranges('sel'):
                text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
                if text.startswith(f'<{tag}>'):
                    if text.endswith(f'</{tag}>'):
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                text = self._remove_format(text, tag)
                self._replace_selected(f'<{tag}>{text}</{tag}>')
            else:
                self.insert('insert', f'<{tag}>')
                endTag = f'</{tag}>'
                self.insert('insert', endTag)
                self.mark_set('insert', f'insert-{len(endTag)}c')
        elif self.tag_ranges('sel'):
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            for tag in self._TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)
        self.colorize()

    def _replace_selected(self, text):
        self.mark_set('insert', tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _remove_format(self, text, tag):
        if tag in self._TAGS:
            finished = False
            while not finished:
                start = text.find(f'<{tag}>')
                if start >= 0:
                    end = text.find(f'</{tag}>')
                    if  start < end:
                        text = (
                            f'{text[:start]}{text[start + len(tag) +2:end]}'
                            f'{text[end + len(tag) + 3:]}'
                        )
                    else:
                        finished = True
                else:
                    finished = True
            return text

import platform



class GenericKeys:

    APPLY_CHANGES = ('<Control-s>', f'{_("Ctrl")}-S')
    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SCENE = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_HELP = ('<F1>', 'F1')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SPLIT_SCENE = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')


class MacKeys(GenericKeys):

    APPLY_CHANGES = ('<Command-s>', 'Cmd-S')
    BOLD = ('<Command-b>', 'Cmd-B')
    CREATE_SCENE = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ITALIC = ('<Command-i>', 'Cmd-I')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SPLIT_SCENE = ('<Command-Alt-s>', 'Cmd-Alt-S')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()



class WriterView(ModalDialog):

    def __init__(self, model, view, controller, prefs):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prefs = prefs
        super().__init__(view, bg=prefs['color_desktop'])

        self._section = None
        self._scId = None

        self.colorModes = [
            (
                _('Bright mode'),
                prefs['color_fg_bright'],
                prefs['color_bg_bright'],
            ),
            (
                _('Light mode'),
                prefs['color_fg_light'],
                prefs['color_bg_light'],
            ),
            (
                _('Dark mode'),
                prefs['color_fg_dark'],
                prefs['color_bg_dark'],
            ),
        ]

        self.attributes('-fullscreen', True)
        self.update_idletasks()
        screenwidth = self.winfo_screenwidth()
        editorWidth = prefs['editor_width']
        if editorWidth > screenwidth:
            editorWidth = screenwidth
        editorWindow = ttk.Frame(
            self,
            width=editorWidth,
        )
        editorWindow.pack(
            expand=True,
            fill='y'
        )

        cm = self.prefs['color_mode']
        self._sectionEditor = EditorBox(
            editorWindow,
            background=self.colorModes[cm][2],
            troughcolor=prefs['color_desktop'],
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=prefs['paragraph_spacing'],
            spacing2=prefs['line_spacing'],
            maxundo=-1,
            padx=prefs['margin_x'],
            pady=prefs['margin_y'],
            font=(
                prefs['font_family'],
                prefs['font_size'],
            ),
            fg=self.colorModes[cm][1],
            bg=self.colorModes[cm][2],
            insertbackground=self.colorModes[cm][1],
        )
        self._sectionEditor.pack(expand=True, fill='both')

        self._statusBar = tk.Frame(
            self,
            background=self._sectionEditor['bg'],
        )
        self._statusBar.pack(
            fill='x',
        )

        self._breadcrumbs = tk.Label(
            self._statusBar,
            background=self._sectionEditor['bg'],
            foreground=self._sectionEditor['fg'],
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._breadcrumbs.pack(
            side='left',
        )

        nextButton = tk.Label(
            self._statusBar,
            background=self._sectionEditor['fg'],
            foreground=self._sectionEditor['bg'],
            text=_('Next'),
            padx=4,
            pady=2,
        )
        nextButton.pack(
            side='right',
        )
        nextButton.bind('<Button-1>', self._load_next)

        tk.Label(
            self._statusBar,
            background=self._sectionEditor['bg'],
            foreground=self._sectionEditor['fg'],
            text=KEYS.NEXT[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )
        self._sectionEditor.bind(
            KEYS.NEXT[0],
            self._load_next,
        )

        closeButton = tk.Label(
            self._statusBar,
            background=self._sectionEditor['fg'],
            foreground=self._sectionEditor['bg'],
            text=_('Close'),
            padx=4,
            pady=2,
        )
        closeButton.pack(
            side='right',
        )
        closeButton.bind('<Button-1>', self.on_quit)

        tk.Label(
            self._statusBar,
            background=self._sectionEditor['bg'],
            foreground=self._sectionEditor['fg'],
            text=KEYS.QUIT_PROGRAM[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )
        self._sectionEditor.bind(
            KEYS.QUIT_PROGRAM[0],
            self.on_quit,
        )

        previousButton = tk.Label(
            self._statusBar,
            background=self._sectionEditor['fg'],
            foreground=self._sectionEditor['bg'],
            text=_('Previous'),
            padx=4,
            pady=2,
        )
        previousButton.pack(
            side='right',
        )
        previousButton.bind('<Button-1>', self._load_prev)

        tk.Label(
            self._statusBar,
            background=self._sectionEditor['bg'],
            foreground=self._sectionEditor['fg'],
            text=KEYS.PREVIOUS[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )
        self._sectionEditor.bind(
            KEYS.PREVIOUS[0],
            self._load_prev,
        )

        self._load_section(self._ui.selectedNode)
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        self.destroy()
        self.isOpen = False

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if messagebox.askyesno('Editor', _('Apply section changes?'), parent=self):
                    try:
                        self._sectionEditor.check_validity()
                    except ValueError as ex:
                        self._ui.show_warning(str(ex))
                        self.lift()
                        return False

                    self._transfer_text(sectionText)
        return True

    def _is_editable(self, scId):
        if not scId or not scId.startswith(SECTION_PREFIX):
            return False

        return self._mdl.novel.sections[scId].scType == 0

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        while nextNode and not self._is_editable(nextNode):
            nextNode = self._ui.tv.next_node(nextNode)
        if nextNode:
            self._scId = nextNode
            self._load_section(self._scId)

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        while prevNode and not self._is_editable(prevNode):
            prevNode = self._ui.tv.prev_node(prevNode)
        if prevNode:
            self._scId = prevNode
            self._load_section(self._scId)

    def _load_section(self, scId=None):
        finished = False
        if not self._is_editable(scId):
            for chId in self._mdl.novel.tree.get_children(CH_ROOT):
                for scId in self._mdl.novel.tree.get_children(chId):
                    if self._is_editable(scId):
                        finished = True
                        break
                if finished:
                    break
        else:
            finished = True
        if not finished:
            return

        self._section = self._mdl.novel.sections[scId]
        self._sectionEditor.clear()
        self._sectionEditor.set_text(
            self._section.sectionContent
        )
        self._scId = scId
        chId = self._mdl.novel.tree.parent(self._scId)

        self._breadcrumbs['text'] = (
            f'{self._mdl.novel.title} | '
            f'{self._mdl.novel.chapters[chId].title} | '
            f'{self._section.title}'
        )

    def _transfer_text(self, sectionText):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        self._section.sectionContent = sectionText



class WriterService(SubController):
    INI_FILENAME = 'writer.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        color_mode=1,
        editor_width=800,
        color_bg_bright='white',
        color_fg_bright='black',
        color_bg_light='navy',
        color_fg_light='gray70',
        color_bg_dark='gray20',
        color_fg_dark='light green',
        color_desktop='gray30',
        font_family='Courier',
        font_size=14,
        line_spacing=7,
        paragraph_spacing=14,
        margin_x=40,
        margin_y=20,
    )
    OPTIONS = dict(
        show_markup=False,
        is_open=False
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
        )
        self.configuration.read(self.iniFile)
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

    def start_editor(self):
        self.writer = WriterView(
            self._mdl,
            self._ui,
            self._ctrl,
            self.prefs,
        )

from abc import ABC, abstractmethod
from pathlib import Path



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '0.1.0'
    API_VERSION = '5.38'
    DESCRIPTION = 'Distraction free editor'
    URL = 'https://github.com/peter88213/nv_writer'
    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_writer'

    FEATURE = _('Edit in distraction free mode')

    def install(self, model, view, controller):
        """Extend the 'View' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.writerService = WriterService(model, view, controller)

        self._ui.toolsMenu.add_command(
            label=self.FEATURE,
            command=self.start_viewer,
        )
        self._ui.toolsMenu.entryconfig(self.FEATURE)

    def start_viewer(self):
        self.writerService.start_editor()

