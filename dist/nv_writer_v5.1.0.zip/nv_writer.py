"""A "distraction free editor mode" plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_writer
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_writer',
        LOCALE_PATH, languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from tkinter import font as tkFont


prefs = {}

BULLET = '* '
COMMENT_PREFIX = 'cmId'
FEATURE = _('Write in distraction free mode')

RESOLUTIONS = [
    (600, 800,),
    (720, 960,),
    (768, 1024,),
    (864, 1152,),
    (900, 1200,),
    (1080, 1440,),
    (1152, 1536,),
    (1200, 1600,),
    (1440, 1920,),
    (1600, 2133,),
]
MIN_HEIGHT, MIN_WIDTH = RESOLUTIONS[0]
DEFAULT_HEIGHT, DEFAULT_WIDTH = RESOLUTIONS[0]

NOTE_MARK = '†'
NOTE_PREFIX = 'ntId'
T_CITATION = 'note-citation'
T_COMMENT = 'comment'
T_CREATOR = 'creator'
T_DATE = 'date'
T_EM = 'em'
T_H5 = 'h5'
T_H6 = 'h6'
T_H7 = 'h7'
T_H8 = 'h8'
T_H9 = 'h9'
T_LI = 'li'
T_NOTE = 'note'
T_SPAN = 'span'
T_STRONG = 'strong'
T_UL = 'ul'

HEADING_TAGS = (T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_TAGS = ('p', T_H5, T_H6, T_H7, T_H8, T_H9)
PARAGRAPH_NESTING_TAGS = (T_COMMENT, T_NOTE)
EMPHASIZING_TAGS = (T_EM, T_STRONG)

FONTS = [
    'DejaVu Sans Mono',  # preferred font, usually bundled with LibreOffice
    'Liberation Mono',
    'Consolas',  # available on Windows
    'Courier',  # fallback, if none of the above is installed
]
INSTALLED_FONTS = tkFont.families()
for editorFont in FONTS:
    if editorFont in INSTALLED_FONTS:
        break

DEFAULT_FONT = editorFont

PRJ_CONFIG_FILE = 'nv_writer.ini'
RECENT = 'RECENT'
RECENT_SECTION = 'section_ID'
RECENT_POSITION = 'position'


def check_editor_settings(window):

    passed = True
    window.update_idletasks()
    resolutionIndex = int(prefs['resolution_index'])
    if resolutionIndex >= len(RESOLUTIONS):
        prefs['resolution_index'] = resolutionIndex = len(RESOLUTIONS) - 1
        passed = False
    elif resolutionIndex < 0:
        prefs['resolution_index'] = resolutionIndex = 0
        passed = False

    height, width = RESOLUTIONS[resolutionIndex]

    screenheight = window.winfo_screenheight()
    while height > screenheight:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    screenwidth = window.winfo_screenwidth()
    while width > screenwidth:
        resolutionIndex -= 1
        height, width = RESOLUTIONS[resolutionIndex]
        prefs['resolution_index'] = resolutionIndex
        passed = False

    if not prefs['editor_font'] in INSTALLED_FONTS:
        prefs['editor_font'] = DEFAULT_FONT

    return passed
import webbrowser



class NvwriterHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_writer/'

    @classmethod
    def open_help_page(cls, page='', event=None):
        webbrowser.open(f'{cls.HELP_URL}{page}')

from tkinter import ttk

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()

import platform



class GenericKeys:

    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    CAPITALIZE = ('<Control-C>', f'{_("Ctrl")}-{_("Shift")}-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CLONE_SECTION = ('<Control-u>', f'{_("Ctrl")}-U')
    CREATE_SECTION = ('<Control-n>', f'{_("Ctrl")}-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DECREASE_SIZE = ('<Control-minus>', f'{_("Ctrl")}--')
    END_WRITING_MODE = ('<F11>', 'F11')
    INCREASE_SIZE = ('<Control-plus>', f'{_("Ctrl")}-+')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    LOWER_CASE = ('<Control-Y>', f'{_("Ctrl")}-{_("Shift")}-Y')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_HELP = ('<Alt-F1>', 'Alt-F1')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SAVE = ('<Control-s>', f'{_("Ctrl")}-S')
    SPLIT_SECTION = ('<Control-l>', f'{_("Ctrl")}-L')
    START_EDITOR = ('<F11>', 'F11')
    TOGGLE_CASE = ('<Control-V>', f'{_("Ctrl")}-{_("Shift")}-V')
    TOGGLE_FOOTER_BAR = ('<F3>', 'F3')
    TOGGLE_HELP = ('<F1>', 'F1')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')
    UPPER_CASE = ('<Control-X>', f'{_("Ctrl")}-{_("Shift")}-X')


class LinuxKeys(GenericKeys):

    INCREASE_SIZE_KP = ('<Control-KP_Add>', f'{_("Ctrl")}-+')
    DECREASE_SIZE_KP = ('<Control-KP_Subtract>', f'{_("Ctrl")}--')
    PREVIOUS_KP = ('<Control-KP_Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    NEXT_KP = ('<Control-KP_Next>', f'{_("Ctrl")}-{_("PgDn")}')


class MacKeys(GenericKeys):

    BOLD = ('<Command-b>', 'Cmd-B')
    CAPITALIZE = ('<Command-C>', f'Cmd-{_("Shift")}-C')
    CLONE_SECTION = ('<Command-u>', 'Cmd-U')
    CREATE_SECTION = ('<Command-n>', 'Cmd-N')
    DECREASE_SIZE = ('<Command-minus>', 'Cmd--')
    INCREASE_SIZE = ('<Command-plus>', 'Cmd-+')
    ITALIC = ('<Command-i>', 'Cmd-I')
    LOWER_CASE = ('<Command-Y>', f'Cmd-{_("Shift")}-Y')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    OPEN_HELP = ('<Command-F1>', 'Cmd-F1')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SAVE = ('<Command-s>', 'Cmd-S')
    SPLIT_SECTION = ('<Command-l>', 'Cmd-L')
    START_EDITOR = ('<Command-w>', 'Cmd-W')
    TOGGLE_CASE = ('<Control-V>', f'Cmd-{_("Shift")}-V')
    UPPER_CASE = ('<Command-X>', f'Cmd-{_("Shift")}-X')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = LinuxKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()


from tkinter import ttk



class ThemePreview(ttk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        uiSize = 10
        wsSize = 12

        self._statusBar = tk.Label(
            self,
            text=_('Status'),
            font=(prefs['editor_font'], uiSize)
        )
        self._statusBar.pack(
            fill='x',
        )

        self._textFrame = tk.Frame(
            self,
            padx=15,
            pady=15,
        )

        self._regularText = tk.Label(
            self._textFrame,
            text=_('Regular text'),
            font=(prefs['editor_font'], wsSize),
        )
        self._regularText.pack(
            anchor='w',
            pady=3,
        )

        self._emphasizedText = tk.Label(
            self._textFrame,
            text=_('Emphasis'),
            font=(prefs['editor_font'], wsSize, 'italic'),
        )
        self._emphasizedText.pack(
            anchor='w',
            pady=3,
        )

        self._strongText = tk.Label(
            self._textFrame,
            text=_('Strong emphasis'),
            font=(prefs['editor_font'], wsSize, 'bold'),
        )
        self._strongText.pack(
            anchor='w',
            pady=3,
        )

        self._invertedText = tk.Label(
            self._textFrame,
            text=_('Comment'),
            font=(prefs['editor_font'], wsSize),
        )
        self._invertedText.pack(
            anchor='w',
            pady=3,
        )

        self.pack(
            anchor='n',
            padx=5,
            pady=5,
            fill='x',
            side='left',
        )
        self._textFrame.pack(fill='x')

        self._footer = tk.Frame(self)
        self._footer.pack(
            fill='x',
        )
        self._button = tk.Label(
            self._footer,
            text=_('Command'),
            font=(prefs['editor_font'], uiSize)
        )
        self._button.pack(
            padx=10,
            fill='x',
        )

        self._shortcut = tk.Label(
            self._footer,
            text=_('Key shortcut'),
            font=(prefs['editor_font'], uiSize)
        )
        self._shortcut.pack(
            fill='x',
        )

    def configure_display(self, colors):
        self._textFrame.configure(
            bg=colors['color_bg'],
        )
        self._statusBar.configure(
            fg=colors['color_status_fg'],
            bg=colors['color_status_bg'],
        )
        self._regularText.configure(
            fg=colors['color_fg'],
            bg=colors['color_bg'],
        )
        self._emphasizedText.configure(
            fg=colors['color_em'],
            bg=colors['color_bg'],
        )
        self._strongText.configure(
            fg=colors['color_strong'],
            bg=colors['color_bg'],
        )
        self._invertedText.configure(
            fg=colors['color_bg'],
            bg=colors['color_fg'],
        )
        self._footer.configure(
            bg=colors['color_bg'],
        )
        self._button.configure(
            fg=colors['color_button_fg'],
            bg=colors['color_button_bg'],
        )
        self._shortcut.configure(
            fg=colors['color_shortcut'],
            bg=colors['color_bg'],
        )


class OptionsDialog(ModalDialog):

    CRT_BG = 'gray15'
    CRT_WHITE_LO = 'gray70'
    CRT_WHITE_HI = 'gray85'
    CRT_GREEN_LO = 'green3'
    CRT_GREEN_HI = 'green2'
    CRT_AMBER_LO = 'orange2'
    CRT_AMBER_HI = 'orange'
    EGA_BLUE = '#0000AA'
    EGA_CYAN = '#00AAAA'
    EGA_RED = '#AA0000'
    EGA_GRAY = '#AAAAAA'
    EGA_GREEN = '#00AA00'
    EGA_BRIGHT_CYAN = '#55FFFF'
    EGA_BRIGHT_RED = '#FF5555'
    EGA_BRIGHT_YELLOW = '#FFFF55'

    THEMES = {
        _('White'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_WHITE_LO,
            color_em=CRT_WHITE_HI,
            color_strong=CRT_WHITE_HI,
            color_notes='red',
            color_status_bg=CRT_WHITE_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_WHITE_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_WHITE_HI,
        ),
        _('Green'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_GREEN_LO,
            color_em=CRT_GREEN_HI,
            color_strong=CRT_GREEN_HI,
            color_notes='yellow',
            color_status_bg=CRT_GREEN_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_GREEN_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_GREEN_HI,
        ),
        _('Amber'): dict(
            color_bg=CRT_BG,
            color_fg=CRT_AMBER_LO,
            color_em=CRT_AMBER_HI,
            color_strong=CRT_AMBER_HI,
            color_notes='yellow',
            color_status_bg=CRT_AMBER_LO,
            color_status_fg=CRT_BG,
            color_button_bg=CRT_AMBER_LO,
            color_button_fg=CRT_BG,
            color_shortcut=CRT_AMBER_HI,
        ),
        f"{_('Contrast')} 1": dict(
            color_bg='black',
            color_fg='white',
            color_em='white',
            color_strong='white',
            color_notes='red',
            color_status_bg='white',
            color_status_fg='black',
            color_button_bg='white',
            color_button_fg='black',
            color_shortcut='white',
        ),
        f"{_('Contrast')} 2": dict(
            color_bg='white',
            color_fg='black',
            color_em='black',
            color_strong='black',
            color_notes='red',
            color_status_bg='black',
            color_status_fg='white',
            color_button_bg='black',
            color_button_fg='white',
            color_shortcut='black',
        ),
        _('Paper'): dict(
            color_bg='floral white',
            color_fg='gray30',
            color_em='gray30',
            color_strong='black',
            color_notes='red',
            color_status_bg='gray60',
            color_status_fg='floral white',
            color_button_bg='gray60',
            color_button_fg='floral white',
            color_shortcut='black',
        ),
        'Perfect5': dict(
            color_bg=EGA_BLUE,
            color_fg=EGA_GRAY,
            color_em=EGA_BRIGHT_YELLOW,
            color_strong='white',
            color_notes=EGA_BRIGHT_RED,
            color_status_bg=EGA_GRAY,
            color_status_fg='black',
            color_button_bg=EGA_GRAY,
            color_button_fg='black',
            color_shortcut='white',
        ),
        'Soft5': dict(
            color_bg=EGA_BLUE,
            color_fg=EGA_GRAY,
            color_em=EGA_BRIGHT_CYAN,
            color_strong='white',
            color_notes=EGA_BRIGHT_RED,
            color_status_bg=EGA_CYAN,
            color_status_fg='black',
            color_button_bg=EGA_GRAY,
            color_button_fg='black',
            color_shortcut=EGA_BRIGHT_CYAN,
        ),
        'Star3': dict(
            color_bg=EGA_CYAN,
            color_fg='black',
            color_em=EGA_BRIGHT_CYAN,
            color_strong=EGA_BRIGHT_CYAN,
            color_notes='white',
            color_status_bg='black',
            color_status_fg=EGA_BRIGHT_CYAN,
            color_button_bg=EGA_RED,
            color_button_fg='white',
            color_shortcut='white',
        ),
        'RJS': dict(
            color_bg='black',
            color_fg='cyan3',
            color_em='gray85',
            color_strong='gray65',
            color_notes='red',
            color_status_bg='green3',
            color_status_fg='black',
            color_button_bg='cyan2',
            color_button_fg='black',
            color_shortcut='cyan2',
        ),
    }

    def __init__(self, view, icon, **kw):
        super().__init__(view, **kw)

        self.title(_('Distraction-free writing plugin Options'))
        if icon:
            self.iconphoto(False, icon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
        )
        optionsFrame = ttk.Frame(window)
        optionsFrame.pack(fill='both')

        askFrame = ttk.Frame(optionsFrame)
        askFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            askFrame,
            text=_('Apply changes')
        ).pack(padx=5, pady=5, anchor='w',)
        self._askForConfirmationVar = tk.BooleanVar(
            askFrame,
            value=prefs['ask_for_confirmation'],
        )
        ttk.Checkbutton(
            askFrame,
            text=_('Ask for confirmation'),
            variable=self._askForConfirmationVar,
            command=self._change_ask_for_confirmation,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        liveFrame = ttk.Frame(optionsFrame)
        liveFrame.pack(side='left', padx=20, pady=10,)
        ttk.Label(
            liveFrame,
            text=_('Word count')
        ).pack(padx=5, pady=5, anchor='w',)
        self._liveWordcountVar = tk.BooleanVar(
            liveFrame,
            value=prefs['live_wordcount'],
        )
        ttk.Checkbutton(
            liveFrame,
            text=_('Live update'),
            variable=self._liveWordcountVar,
            command=self._change_live_wc,
        ).pack(padx=5, pady=5, anchor='w',)

        ttk.Separator(
            optionsFrame,
            orient='vertical'
        ).pack(fill='y', side='left',)

        ttk.Separator(
            window,
            orient='horizontal',
        ).pack(fill='x')

        currentSettingsFrame = ttk.Frame(window)
        currentSettingsFrame.pack(fill='both')
        ttk.Label(
            currentSettingsFrame,
            text=_('Color sets'),
        ).pack(padx=5, pady=5, anchor='w')
        self._currentSettingPreview = ThemePreview(currentSettingsFrame)
        ttk.Label(
            self._currentSettingPreview,
            text=_('Current setting'),
        ).pack(pady=5)
        self._update_colors()

        themesPerFrame = 5
        themeFrames = []
        for __ in range((len(self.THEMES) + 1) // themesPerFrame):
            themeFrames.append(ttk.Frame(window))
            themeFrames[-1].pack(fill='both')

        for i, theme in enumerate(self.THEMES):
            preview = ThemePreview(themeFrames[i // themesPerFrame])
            preview.configure_display(self.THEMES[theme])
            ttk.Button(
                preview,
                text=theme,
                command=lambda t=theme: self._set_option(t)
            ).pack(pady=5)

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], NvwriterHelp.open_help_page)

    def _change_live_wc(self):
        prefs['live_wordcount'] = self._liveWordcountVar.get()

    def _change_ask_for_confirmation(self):
        prefs['ask_for_confirmation'] = self._askForConfirmationVar.get()

    def _change_colors(self, *args, **kwargs):
        pass

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('options.html')

    def _set_option(self, theme):
        for color in self.THEMES[theme]:
            prefs[color] = self.THEMES[theme][color]
        self._update_colors()

    def _update_colors(self):
        self._currentSettingPreview.configure_display(
            dict(
                color_bg=prefs['color_bg'],
                color_fg=prefs['color_fg'],
                color_em=prefs['color_em'],
                color_strong=prefs['color_strong'],
                color_notes=prefs['color_notes'],
                color_status_bg=prefs['color_status_bg'],
                color_status_fg=prefs['color_status_fg'],
                color_button_bg=prefs['color_button_bg'],
                color_button_fg=prefs['color_button_fg'],
                color_shortcut=prefs['color_shortcut'],
            )
        )

from pathlib import Path



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from tkinter import ttk


def make_scrollbar_style(
    troughcolor='black',
    background='grey',
):
    style = ttk.Style()
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.trough',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.thumb',
        'from',
        'default',
    )
    style.element_create(
        'CustomScrollbarStyle.Vertical.Scrollbar.grip',
        'from',
        'default',
    )
    style.layout(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        [(
            'CustomScrollbarStyle.Vertical.Scrollbar.trough',
            {
                'children': [
                    ('CustomScrollbarStyle.Vertical.Scrollbar.thumb',
                        {
                            'unit': '1',
                            'children': [(
                                'CustomScrollbarStyle.Vertical.Scrollbar.grip',
                                {'sticky': ''}
                            )],
                            'sticky': 'nswe'
                        }
                    )
                ],
                'sticky': 'ns'
            }
        )]
    )
    style.configure(
        'CustomScrollbarStyle.Vertical.TScrollbar',
        troughcolor=troughcolor,
        background=background,
    )

from configparser import ConfigParser
from tkinter import ttk



from xml import sax



class Comment:

    def __init__(self):
        self.creator = ''
        self.date = ''
        self.text = ''

    def add_text(self, text, separator=''):
        if not self.text:
            self.text = text
        else:
            self.text = f'{self.text}{separator}{text}'

    def get_xml(self):
        text = self.text.replace('\n', '</p><p>')
        return(
            '<comment>'
            f'<creator>{self.creator}</creator>'
            f'<date>{self.date}</date>'
            f'<p>{text}</p>'
            '</comment>'
        )



class Note(Comment):

    def __init__(self):
        self.noteId = ''
        self.noteClass = ''
        self.noteCitation = ''
        self.text = ''

    def get_xml(self):
        return(
            f'<note id="{self.noteId}" class="{self.noteClass}">'
            f'<note-citation>{self.noteCitation}</note-citation>'
            f'<p>{self.text}</p>'
            '</note>'
        )



class NovxParser(sax.ContentHandler):

    def __init__(self):
        super().__init__()

        self._taggedText = []

        self._tags = []

        self._spans = []

        self.comments = []

        self.notes = []

        self._list = None

        self._noteXmlTag = None

        self._commentXmlTag = None

    def feed(self, xmlString):
        self._taggedText.clear()
        self._tags.clear()
        self._spans.clear()
        self.comments.clear()
        self.notes.clear()
        self._list = False
        self._noteXmlTag = None
        self._commentXmlTag = None
        self._sectionStart = True

        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):

        if self._noteXmlTag == T_CITATION:
            self.notes[-1].noteCitation = content
            return

        if self._noteXmlTag == 'p':
            self.notes[-1].add_text(content, '\n')
            return

        if self._commentXmlTag == T_CREATOR:
            self.comments[-1].creator = content
            return

        if self._commentXmlTag == T_DATE:
            self.comments[-1].date = content
            return

        if self._commentXmlTag == 'p':
            self.comments[-1].add_text(content, '\n')
            return

        tags = []
        if self._tags:
            self._tags.reverse()
            tags.extend(self._tags)
        self._taggedText.append((content, tags))

    def endElement(self, name):
        if name == T_COMMENT:
            tags = [
                T_COMMENT,
                f'{COMMENT_PREFIX}:{len(self.comments)-1}',
            ]
            if self._tags:
                tags.extend(self._tags)
            self._taggedText.append((self.comments[-1].text, tags))
            self._commentXmlTag = None
            return

        if name == T_NOTE:
            tags = [
                T_NOTE,
                f'{NOTE_PREFIX}:{len(self.notes)-1}',
            ]
            if self._tags:
                tags.extend(self._tags)
            self._taggedText.append((NOTE_MARK, tags))
            self._noteXmlTag = None
            return

        if name in EMPHASIZING_TAGS:
            self._tags.remove(name)
            return

        if name == T_SPAN:
            self._tags.remove(self._spans.pop())
            return

        if name in PARAGRAPH_TAGS:
            if self._commentXmlTag is None and self._noteXmlTag is None:
                self._spans.clear()
                self._tags.clear()
            return

        if name == T_UL:
            self._list = False
            return

    def get_result(self, debug=False):
        if debug:
            print(self._taggedText)
        return self._taggedText

    def startElement(self, name, attrs):

        if name == T_COMMENT:
            self.comments.append(Comment())
            self._commentXmlTag = name
            return

        if self._commentXmlTag is not None:
            self._commentXmlTag = name
            return

        if name == T_NOTE:
            self.notes.append(Note())
            self._noteXmlTag = name
            self.notes[-1].noteId = attrs['id']
            self.notes[-1].noteClass = attrs['class']
            return

        if self._noteXmlTag is not None:
            self._noteXmlTag = name
            return


        attributes = []
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes.append(f'{attrKey}="{attrValue}"')

        suffix = ''

        if name == 'p':
            if self._taggedText and not self._list:
                suffix = '\n'
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)

        elif name in EMPHASIZING_TAGS:
            self._tags.append(name)

        elif name == T_SPAN:
            span = f"{name}_{'_'.join(attributes)}"
            self._spans.append(span)
            self._tags.append(span)

        elif name in HEADING_TAGS:
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)
            else:
                self._tags.append(name)
            if self._taggedText:
                suffix = '\n'

        elif name == T_LI:
            if self._sectionStart:
                self._sectionStart = False
                suffix = BULLET
            else:
                suffix = f'\n{BULLET}'

        elif name == T_UL:
            if self._taggedText:
                self._sectionStart = False
            self._list = True

        if suffix:
            self._taggedText.append((suffix, ''))
from xml.sax.saxutils import escape

import re


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



class TextParser():

    def __init__(self):
        self.comments = []

        self._commentIndex = None

        self.notes = []

        self._noteIndex = None

        self._paragraph = None

        self._xmlList = []

        self._xmlStack = []
        self._transferStack = []

    @property
    def _list(self):
        return T_UL in self._xmlStack

    def reset(self, debug=False):
        self._paragraph = False
        self._xmlList.clear()
        self._commentIndex = None
        self._noteIndex = None
        self._xmlStack.clear()
        self._transferStack.clear()
        self.debug = debug

    def parse_triple(self, key, value, __):
        if self.debug:
            print(key, value)
        if key == 'text' and value:
            self.characters(value)
        elif key == 'tagon' and value:
            self.startElement(value)
        elif key == 'tagoff' and value:
            self.endElement(value)

    def characters(self, content):

        content = escape(content)
        content = strip_illegal_characters(content)

        if self._commentIndex is not None:

            self.comments[self._commentIndex].add_text(content)
            return

        if self._noteIndex is not None:

            return

        if not self._paragraph:

            if content.startswith(BULLET):
                content = content.lstrip(BULLET)
                if not self._list:
                    self._start_xml(T_UL)
                self._start_xml(T_LI)

            elif self._list:
                self._end_xml()

            self._start_paragraph()

        if content.endswith('\n'):

            self._xmlList.append(content.rstrip('\n'))

            self._end_paragraph()

            if self._list:
                self._end_xml()
            return

        self._xmlList.append(content)

    def endElement(self, name):
        if name in EMPHASIZING_TAGS:
            self._end_xml()
            return

        if name.startswith(T_SPAN):
            self._end_xml()
            return

        if name.startswith(COMMENT_PREFIX):
            self._xmlList.append(self.comments[self._commentIndex].get_xml())
            self._commentIndex = None
            return

        if name.startswith(NOTE_PREFIX):
            self._xmlList.append(self.notes[self._noteIndex].get_xml())
            self._noteIndex = None
            return

    def get_result(self):
        while self._xmlStack:
            self._end_xml()
        return ''.join(self._xmlList)

    def startElement(self, name):
        if name.startswith(COMMENT_PREFIX):
            self._commentIndex = int(name.split(':')[1])
            self.comments[self._commentIndex].text = ''
            return

        if name.startswith(NOTE_PREFIX):
            self._noteIndex = int(name.split(':')[1])
            return

        if  name.split('_')[0] in PARAGRAPH_TAGS:
            if self._list:
                self._end_xml()
            self._start_paragraph(name=name)
            return

        if not self._paragraph and name != 'sel':
            self._start_paragraph()

        if name in EMPHASIZING_TAGS:
            self._start_xml(name)
            return

        if name.startswith(T_SPAN):
            self._start_xml(name)
            return

    def _end_paragraph(self):
        self._paragraph = False

        while self._xmlStack:
            tag = self._xmlStack.pop()
            if self.debug:
                print(f'* Closing {tag}')
            self._xmlList.append(f'</{tag}>')
            if not tag in PARAGRAPH_TAGS:
                self._transferStack.append(tag)
            else:
                break

    def _end_xml(self):
        if self._xmlStack:
            tag = self._xmlStack.pop()
            if self.debug:
                print(f'* Closing {tag}')
            self._xmlList.append(f'</{tag}>')

    def _start_paragraph(self, name='p'):
        self._paragraph = True

        self._start_xml(name)
        while self._transferStack:
            tag = self._transferStack.pop()
            if self.debug:
                print(f'* Opening {tag}')
            self._xmlStack.append(tag)
            self._xmlList.append(f'<{tag}>')

    def _start_xml(self, name):
        tag = name.split('_')[0]
        if self.debug:
            print(f'* Opening {tag}')
        self._xmlStack.append(tag)
        self._xmlList.append(f'<{name.replace("_", " ")}>')
from tkinter import font as tkFont
from tkinter import ttk


class EditorBox(tk.Text):

    def __init__(
        self,
        master=None,
        vstyle=None,
        **kw,
    ):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        if vstyle is not None:
            self.vbar.configure(style=vstyle)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self._novxParser = NovxParser()
        self._textParser = TextParser()

        self.configure_font(kw['font'])
        self.tag_configure(
            T_COMMENT,
            background=kw['fg'],
            foreground=kw['bg'],
        )
        self.tag_configure(
            T_NOTE,
            foreground=prefs['color_notes'],
        )

        self.debug = False

    def capitalize(self):
        if not self.tag_ranges('sel'):
            return

        self._replace_selected(
            self.get(tk.SEL_FIRST, tk.SEL_LAST).capitalize()
        )

    def clear(self):
        self.delete('1.0', 'end')

    def configure_font(self, font):
        defaultFont = tkFont.Font(
            root=self,
            font=font,
            name='editor_font',
        )

        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')

        self.tag_configure(
            T_EM,
            font=italicFont,
            foreground=prefs['color_em'],
        )
        self.tag_configure(
            T_STRONG,
            font=boldFont,
            foreground=prefs['color_strong'],
        )

    def emphasis(self):
        return self._set_format(T_EM)

    def get_text(self, start='1.0', end='end'):
        self._textParser.reset(debug=self.debug)
        self._textParser.comments = self._novxParser.comments
        self._textParser.notes = self._novxParser.notes
        self.dump(start, end, command=self._textParser.parse_triple)
        return self._textParser.get_result()

    def plain(self):
        isModified = False
        if self.tag_ranges('sel'):
            index = 'sel.first'
            while not isModified and self.compare(index, '<=', 'sel.last'):
                tags = self.tag_names(index)
                for tag in tags:
                    if tag in EMPHASIZING_TAGS:
                        isModified = True
                        break
                index = self.index(f'{index}+1c')
                if self.compare(index, '>=', 'end'):
                    break
            for tag in EMPHASIZING_TAGS:
                self.tag_remove(tag, 'sel.first', 'sel.last')
        return isModified

    def set_text(self, text):
        if text:
            self._novxParser.feed(text)
            taggedText = self._novxParser.get_result(debug=self.debug)
        else:
            taggedText = []

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index

        self.edit_reset()
        self.mark_set('insert', f'1.0')

    def strong_emphasis(self):
        return self._set_format(T_STRONG)

    def to_lowercase(self):
        if not self.tag_ranges('sel'):
            return

        self._replace_selected(
            self.get(tk.SEL_FIRST, tk.SEL_LAST).lower()
        )

    def to_uppercase(self):
        if not self.tag_ranges('sel'):
            return

        self._replace_selected(
            self.get(tk.SEL_FIRST, tk.SEL_LAST).upper()
        )

    def toggle_case(self):
        if not self.tag_ranges('sel'):
            return
        string = self.get(tk.SEL_FIRST, tk.SEL_LAST)
        toggled = []
        for c in string:
            if c.isupper():
                toggled.append(c.lower())
            else:
                toggled.append(c.upper())
        self._replace_selected(''.join(toggled))

    def _replace_selected(self, text):
        self.mark_set('insert', 'sel.first')
        self.delete('sel.first', 'sel.last')
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _set_format(self, newTag):
        if not self.tag_ranges('sel'):
            return False

        willModify = False
        index = 'sel.first'
        while self.compare(index, '<=', 'sel.last'):
            if not newTag in self.tag_names(index):
                willModify = True
                break

            index = self.index(f'{index}+1c')
            if self.compare(index, '>=', 'end'):
                break

        if not willModify:
            return False

        firstCharTags = [newTag]
        for tag in self.tag_names('sel.first'):
            if tag in EMPHASIZING_TAGS:
                self.tag_remove(tag, 'sel.first')
            elif tag.split('_')[0] in PARAGRAPH_TAGS:
                self.tag_remove(tag, 'sel.first')
                firstCharTags.append(tag)
        for tag in firstCharTags:
            self.tag_add(tag, 'sel.first')

        for tag in EMPHASIZING_TAGS:
            self.tag_remove(tag, 'sel.first+1c', 'sel.last')
            self.tag_add(newTag, 'sel.first+1c', 'sel.last')

        return True



class FooterBar(tk.Frame):

    def __init__(self, parent, **kw):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        super().__init__(parent, background=prefs['color_bg'], **kw,)

        self._entries = []
        for desc, shortcut, sequence in (
            (_('New'), KEYS.CREATE_SECTION[1], '<<new_section>>',),
            (_('Split'), KEYS.SPLIT_SECTION[1], '<<split_section>>',),
            (_('Clone'), KEYS.CLONE_SECTION[1], '<<clone_section>>',),
            (_('Previous'), KEYS.PREVIOUS[1], '<<load_prev>>',),
            (_('Next'), KEYS.NEXT[1], '<<load_next>>',),
            (_('Save'), KEYS.SAVE[1], '<<save>>',),
            (_('Close'), KEYS.END_WRITING_MODE[1], '<<on_quit>>',),
        ):
            event = callback
            menuEntry = tk.Frame(
                self,
                background=prefs['color_bg'],
                padx=1,
                pady=1,
            )
            descLabel = tk.Label(
                menuEntry,
                background=prefs['color_button_bg'],
                foreground=prefs['color_button_fg'],
                text=desc,
            )
            descLabel.pack(
                fill='x',
                expand=True,
            )
            descLabel.bind('<Button-1>', event)
            shortcutLabel = tk.Label(
                menuEntry,
                background=prefs['color_bg'],
                foreground=prefs['color_shortcut'],
                text=shortcut,
            )
            shortcutLabel.pack(
                fill='x',
                expand=True,
            )
            shortcutLabel.bind('<Button-1>', event)
            menuEntry.pack(
                side='left',
                padx=4,
                pady=2,
                fill='x',
                expand=True,
            )
            self._entries.append((descLabel, shortcutLabel))

    def set_font(self, scale):
        size = int(int(prefs['font_size_1']) * scale * 0.8)
        font = (prefs['editor_font'], size)
        for descLabel, shortcutLabel in self._entries:
            descLabel.configure(font=font)
            shortcutLabel.configure(font=font)



class HelpScreen(tk.Frame):

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=prefs['color_bg'],)

        self._frameWidth = 1
        self._outerFrame = tk.Frame(
            self,
            padx=self._frameWidth,
            pady=self._frameWidth,
            bg=prefs['color_fg'],
        )
        self._outerFrame.pack(
            fill='both',
            padx=6,
            pady=6,
        )
        self._headings = []
        self._entries = []

        leftFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        leftFrame.pack(
            side='left',
            anchor='n',
            fill='both',
        )
        innerFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        innerFrame.pack(
            side='left',
            anchor='n',
            fill='both',
            expand=True,
        )
        middleFrame = tk.Frame(
            innerFrame,
        )
        middleFrame.pack(
            anchor='n',
        )
        rightFrame = tk.Frame(
            self._outerFrame,
            padx=6,
            pady=6,
            bg=prefs['color_bg'],
        )
        rightFrame.pack(
            side='right',
            anchor='n',
            fill='both',
        )

        frame = leftFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('View'), row)
        )
        for desc, shortcut in (
            (_('Word count'), KEYS.UPDATE_WORDCOUNT[1],),
            (_('Menu on/off'), KEYS.TOGGLE_FOOTER_BAR[1],),
            (_('Help on/off'), KEYS.TOGGLE_HELP[1],),
            (_('Online help'), KEYS.OPEN_HELP[1],),
            (_('Enlarge'), KEYS.INCREASE_SIZE[1],),
            (_('Shrink'), KEYS.DECREASE_SIZE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        row += 1

        self._headings.append(
            self._create_heading(frame, _('Change case'), row)
        )
        for desc, shortcut in (
            (_('UPPERCASE'), KEYS.UPPER_CASE[1],),
            (_('lowercase'), KEYS.LOWER_CASE[1],),
            (_('Capitalize'), KEYS.CAPITALIZE[1],),
            (_('tOGGLE cASE'), KEYS.TOGGLE_CASE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        frame = middleFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('Edit'), row)
        )
        for desc, shortcut in (
            (_('Cut'), KEYS.CUT[1],),
            (_('Copy'), KEYS.COPY[1],),
            (_('Paste'), KEYS.PASTE[1],),
            (_('Swap characters'), f'{_("Ctrl")}-T'),
            (_('Delete character left'), f'{_("Ctrl")}-H'),
            (_('Delete to end of line'), f'{_("Ctrl")}-K'),
            (_('Delete character right'), f'{_("Ctrl")}-D'),
            (_('Open new line'), f'{_("Ctrl")}-O'),
            (_('Undo'), f'{_("Ctrl")}-Z'),
            (_('Redo'), f'{_("Ctrl")}-Y'),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        frame = rightFrame
        row = 0

        self._headings.append(
            self._create_heading(frame, _('Format'), row)
        )
        for desc, shortcut in (
            (_('Emphasis'), KEYS.ITALIC[1],),
            (_('Strong emphasis'), KEYS.BOLD[1],),
            (_('Plain'), KEYS.PLAIN[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

        row += 1

        self._headings.append(
            self._create_heading(frame, _('Section'), row)
        )
        for desc, shortcut in (
            (_('New'), KEYS.CREATE_SECTION[1],),
            (_('Split'), KEYS.SPLIT_SECTION[1],),
            (_('Clone'), KEYS.CLONE_SECTION[1],),
            (_('Previous'), KEYS.PREVIOUS[1],),
            (_('Next'), KEYS.NEXT[1],),
            (_('Save'), KEYS.SAVE[1],),
            (_('Close'), KEYS.END_WRITING_MODE[1],),
        ):
            row += 1
            self._entries.append(
                self._create_help_entry(frame, desc, shortcut, row)
            )

    def _create_heading(self, parent, heading, row):

        headingLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_shortcut'],
            text=heading,
            anchor='w',
            padx=10,
        )
        headingLabel.grid(
            row=row,
            column=0,
            columnspan=2,
            sticky="ew",
        )
        return headingLabel

    def _create_help_entry(self, parent, desc, shortcut, row):

        descLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=desc,
            anchor='w',
            padx=10,
        )
        descLabel.grid(
            row=row,
            column=0,
            sticky="ew",
        )
        shortcutLabel = tk.Label(
            parent,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=shortcut,
            anchor='w',
            padx=10,
        )
        shortcutLabel.grid(
            row=row,
            column=1,
            sticky="ew",
        )
        return descLabel, shortcutLabel

    def set_font(self, scale):
        size = int(int(prefs['font_size_1']) * scale * 0.8)
        accFont = (prefs['editor_font'], size, 'bold')
        dscFont = (prefs['editor_font'], size)
        for descLabel, shortcutLabel in self._entries:
            shortcutLabel.configure(font=accFont)
            descLabel.configure(font=dscFont)
        hdFont = (prefs['editor_font'], size, 'bold')
        for headinglabel in self._headings:
            headinglabel.configure(font=hdFont)
        self._outerFrame.configure(
            padx=self._frameWidth * scale,
            pady=self._frameWidth * scale,
        )

from xml import sax



class SectionContentValidator(sax.ContentHandler):

    def validate_section(self, xmlString):
        self.text = False
        self.nestedParagraph = False
        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, __):
        if not self.text and not self.nestedParagraph:
            raise RuntimeError('Section content validation failed')

    def endElement(self, name):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = False

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = False

    def startElement(self, name, __):
        if not self.nestedParagraph and name in PARAGRAPH_TAGS:
            self.text = True

        elif name in PARAGRAPH_NESTING_TAGS:
            self.nestedParagraph = True

import textwrap



class StatusBar(tk.Frame):

    def __init__(self, parent, model, **kw):
        super().__init__(
            parent,
            **kw,
        )
        self._mdl = model

        self._lockModificationIndicator = False

        self._wordCount = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._wordCount.pack(
            side='right',
        )

        self._modificationIndicator = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._modificationIndicator.pack(
            side='right',
        )

        self._breadcrumbs = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._breadcrumbs.pack(
            side='left',
        )

    def highlight(self):
        self.configure(background=prefs['color_status_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_status_fg'],
            background=prefs['color_status_bg'],
        )

    def normal(self):
        self.configure(background=prefs['color_bg'])
        self._breadcrumbs.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )
        self._modificationIndicator.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )
        self._wordCount.configure(
            foreground=prefs['color_fg'],
            background=prefs['color_bg'],
        )

    def set_breadcrumbs(self, book, chapter, section):
        lengthTotal = 80
        lengthEntry = 25
        if book:
            book = textwrap.shorten(book, lengthEntry)
        lengthTotal -= len(book)
        lengthEntry = lengthTotal // 2
        if chapter:
            chapter = textwrap.shorten(chapter, lengthEntry)
        lengthTotal -= len(chapter)
        self._breadcrumbs.configure(
            text=(f'{book} | {chapter} | {section}')
        )

    def set_font(self, scale):
        size = int(int(prefs['font_size_1']) * scale * 0.8)
        font = (prefs['editor_font'], size)
        self._breadcrumbs.configure(font=font)
        self._modificationIndicator.configure(font=font)
        self._wordCount.configure(font=font)

    def set_modified(self, isModified):
        if isModified:
            self._modificationIndicator.configure(text=f"[{_('Modified')}]")
            self._lockModificationIndicator = False
        elif not self._lockModificationIndicator:
            self._modificationIndicator.configure(text='')

    def set_saved(self):
        self._modificationIndicator.configure(text=f"[{_('Saved')}]")
        self._lockModificationIndicator = True

    def set_wordcount(self, wcText):
        self._wordCount.configure(text=wcText)



class WriterView(ModalDialog):

    def __init__(
        self,
        model,
        view,
        controller,
    ):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._focus_app_window(False)
        super().__init__(view, bg=prefs['color_desktop'])

        self._section = None
        self._scId = None
        self.wordCounter = self._mdl.nvService.get_word_counter()
        self._initialWc = 0
        self._actualWordCount = None

        self.attributes('-fullscreen', True)
        check_editor_settings(self)

        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        self._editorWindow = ttk.Frame(
            self,
            height=height,
            width=width,
        )
        self._editorWindow.pack(expand=True,)
        self._editorWindow.pack_propagate(0)

        self._statusBar = StatusBar(self._editorWindow, self._mdl)
        self._statusBar.set_font(scale)
        self._statusBar.pack(fill='x')

        self._helpScreen = HelpScreen(
            self._editorWindow,
        )
        self._helpScreen.set_font(scale)


        ttk.Style().configure(
            'CustomScrollbarStyle.Vertical.TScrollbar',
            troughcolor=prefs['color_bg'],
            background=prefs['color_desktop'],
        )

        self._sectionEditor = EditorBox(
            self._editorWindow,
            vstyle='CustomScrollbarStyle.Vertical.TScrollbar',
            wrap='word',
            undo=True,
            maxundo=-1,
            autoseparators=True,
            fg=prefs['color_fg'],
            bg=prefs['color_bg'],
            insertbackground=prefs['color_fg'],
            spacing1=int(int(prefs['paragraph_spacing']) * scale),
            spacing2=int(int(prefs['line_spacing']) * scale),
            padx=int(int(prefs['margin_horizontal']) * scale),
            pady=int(int(prefs['margin_vertical']) * scale),
            font=(
                prefs['editor_font'],
                int(int(prefs['font_size_1']) * scale),
            ),
        )
        self._sectionEditor.pack(fill='both', expand=True)

        self._footerBar = FooterBar(self._editorWindow)
        self._footerBar.set_font(scale)

        if prefs['show_footer_bar']:
            self._show_footer_bar()
            self._statusBar.highlight()
        else:
            self._statusBar.normal()
        if prefs['show_help_screen']:
            self._show_help_screen()

        keyBindings = [
            (KEYS.INCREASE_SIZE, self._increase_screen_size),
            (KEYS.DECREASE_SIZE, self._decrease_screen_size),
            (KEYS.PREVIOUS, self._load_prev),
            (KEYS.NEXT, self._load_next),
            (KEYS.OPEN_HELP, self._open_help),
            (KEYS.QUIT_PROGRAM, self.on_quit),
            (KEYS.END_WRITING_MODE, self.on_quit),
            (KEYS.UPDATE_WORDCOUNT, self._show_wordcount),
            (KEYS.SPLIT_SECTION, self._split_section),
            (KEYS.CREATE_SECTION, self._create_section),
            (KEYS.CLONE_SECTION, self._clone_section),
            (KEYS.ITALIC, self._emphasis),
            (KEYS.BOLD, self._strong_emphasis),
            (KEYS.PLAIN, self._plain),
            (KEYS.SAVE, self._save_project),
            (KEYS.TOGGLE_FOOTER_BAR, self._toggle_display),
            (KEYS.TOGGLE_HELP, self._toggle_help),
            (KEYS.UPPER_CASE, self._to_uppercase),
            (KEYS.LOWER_CASE, self._to_lowercase),
            (KEYS.CAPITALIZE, self._capitalize),
            (KEYS.TOGGLE_CASE, self._toggle_case),
        ]
        if PLATFORM == 'ix':
            keyBindings.extend(
                [
                    (KEYS.INCREASE_SIZE_KP, self._increase_screen_size),
                    (KEYS.DECREASE_SIZE_KP, self._decrease_screen_size),
                    (KEYS.NEXT_KP, self._load_next),
                    (KEYS.PREVIOUS_KP, self._load_prev),
                ]
            )
        for key, callback in keyBindings:
            self._sectionEditor.bind(key[0], callback)

        eventBindings = (
            ('<<load_next>>', self._load_next),
            ('<<on_quit>>', self.on_quit),
            ('<<load_prev>>', self._load_prev),
            ('<<split_section>>', self._split_section),
            ('<<clone_section>>', self._clone_section),
            ('<<new_section>>', self._create_section),
            ('<<save>>', self._save_project),
        )
        for sequence, callback in eventBindings:
            self.bind(sequence, callback)

        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._set_wc_mode()
        self._askForConfirmation = prefs['ask_for_confirmation']

        self._validator = SectionContentValidator()

        fields = self._mdl.novel.fields
        fields.pop('writer-last-position', None)
        self._mdl.novel.fields = fields

        prjDir, __ = os.path.split(self._mdl.prjFile.filePath)
        self.prjConfigFile = os.path.join(prjDir, PRJ_CONFIG_FILE)
        prjConfig = ConfigParser()
        prjConfig.read(self.prjConfigFile)
        try:
            recent = prjConfig[RECENT]
        except:
            lastScId = lastCursorPos = None
        else:
            lastScId = recent.get(RECENT_SECTION, None)
            lastCursorPos = recent.get(RECENT_POSITION, None)
            if not self._is_editable(lastScId):
                lastScId = lastCursorPos = None

        scId = self._ui.selectedNode
        cursorPos = '1.0'
        if self._is_editable(scId):
            if scId == lastScId:
                cursorPos = lastCursorPos
        elif lastScId is not None:
            scId = lastScId
            cursorPos = lastCursorPos
        else:
            scId = self._get_first_editable_section()
            if scId is None:
                self.on_quit()
                return

        self._load_section(scId, cursorPos=cursorPos)

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        prjConfig = ConfigParser()
        prjConfig.add_section(RECENT)
        prjConfig.set(
            RECENT,
            RECENT_SECTION,
            self._scId,
        )
        prjConfig.set(
            RECENT,
            RECENT_POSITION,
            self._sectionEditor.index('insert'),
        )
        with open(self.prjConfigFile, 'w') as f:
            prjConfig.write(f)

        self._focus_app_window(True)
        self.destroy()

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        sectionText = self._get_edited_section_content()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._section.sectionContent = sectionText

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._get_edited_section_content()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                result = self._confirm(message=_('Apply section changes?'))
                if result is None:
                    return False

                if result:
                    self._section.sectionContent = sectionText
        return True

    def _capitalize(self, event=None):
        self._sectionEditor.capitalize()
        return 'break'

    def _confirm(self, message):
        if self._askForConfirmation:
            return self._ui.ask_yes_no_cancel(
                message=message,
                title=FEATURE,
                parent=self,
            )
        else:
            return True

    def _clone_section(self, event=None):
        self._apply_changes()
        self._mdl.clone_section(self._scId)

    def _create_section(self, event=None):
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        self._askForConfirmation = False
        return newId

    def _decrease_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex > 0:
            resolutionIndex -= 1
            prefs['resolution_index'] = resolutionIndex
            self._reconfigure_screen()

    def _emergency_exit(self, message='Conversion error', detail=''):
        self._focus_app_window(True)
        self.destroy()
        self._ui.show_error(
            message=message,
            detail=(
                'Distraction-free mode aborted '
                'in order not to cause damage to your project. '
                'You can ignore the following "Unexpected Error" message '
                'and continue without distraction-free mode.'
                f'{detail}'
            ),
            title='nv_writer debug message',
        )
        raise UserWarning('nv_writer aborted to prevent damage.')

    def _emphasis(self, event=None):
        if self._sectionEditor.emphasis():
            self._statusBar.set_modified(True)
        return 'break'

    def _focus_app_window(self, giveFocus):
        if giveFocus:
            if PLATFORM == 'win':
                self._ui.root.deiconify()
            self._ui.root.lift()
        else:
            if PLATFORM == 'win':
                self._ui.root.iconify()

    def _freeze_wordcount(self, event=None):
        self._statusBar.set_wordcount(
            f'{KEYS.UPDATE_WORDCOUNT[1]}: {_("Count words")}'
        )

    def _get_edited_section_content(self):
        try:
            sectionText = self._sectionEditor.get_text()
            self._validator.validate_section(sectionText)
        except:
            savedText = self._sectionEditor.get('1.0', 'end')
            emergencyFile = f'{self._mdl.prjFile.filePath}_{self._scId}.txt'
            with open(emergencyFile, 'w', encoding='utf-8') as f:
                f.write(savedText)
            self._emergency_exit(
                detail=(
                    '\n\nThe edited section is saved as plain text in '
                    f'"{emergencyFile}".'
                ),
            )
        else:
            return sectionText

    def _get_first_editable_section(self):
        result = None
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            for scId in self._mdl.novel.tree.get_children(chId):
                if self._is_editable(scId):
                    result = scId
                    break
            if result is not None:
                break
        return result

    def _hide_help_screen(self, event=None):
        self._helpScreen.pack_forget()
        prefs['show_help_screen'] = False
        return 'break'

    def _hide_footer_bar(self, event=None):
        self._footerBar.pack_forget()
        prefs['show_footer_bar'] = False
        return 'break'

    def _increase_screen_size(self, event=False):
        resolutionIndex = int(prefs['resolution_index'])
        if resolutionIndex < len(RESOLUTIONS) - 1:
            resolutionIndex += 1
            prefs['resolution_index'] = resolutionIndex
            if check_editor_settings(self):
                self._reconfigure_screen()

    def _is_editable(self, scId):
        if not scId in self._mdl.novel.sections:
            return False

        return self._mdl.novel.sections[scId].scType == 0

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        while nextNode and not self._is_editable(nextNode):
            nextNode = self._ui.tv.next_node(nextNode)
        if nextNode:
            self._load_section(nextNode)

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        while prevNode and not self._is_editable(prevNode):
            prevNode = self._ui.tv.prev_node(prevNode)
        if prevNode:
            self._load_section(prevNode)

    def _load_section(self, scId, cursorPos='1.0'):
        self._sectionEditor.unbind("<<Modified>>")
        self._ui.tv.go_to_node(scId)
        self._section = self._mdl.novel.sections[scId]
        self._scId = scId
        self._sectionEditor.clear()
        try:
            msg = 'Cannot load text.'
            self._sectionEditor.set_text(self._section.sectionContent)
            msg = 'Validation error.'
            self._validator.validate_section(self._sectionEditor.get_text())
        except:
            self._emergency_exit(message=msg)

        try:
            self._sectionEditor.mark_set('insert', cursorPos)
            self._sectionEditor.see('insert')
        except:
            pass

        chId = self._mdl.novel.tree.parent(scId)

        self._statusBar.set_breadcrumbs(
            self._mdl.novel.title,
            self._mdl.novel.chapters[chId].title,
            self._section.title
        )
        self._initialWc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        self._show_wordcount(wc=self._initialWc)
        self._reset_modified_flag()
        self._sectionEditor.bind(
            "<<Modified>>",
            self._update_modified_flag
        )
        self._askForConfirmation = prefs['ask_for_confirmation']
        self._sectionEditor.focus()

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('operation.html')
        return 'break'

    def _plain(self, event=None):
        if self._sectionEditor.plain():
            self._statusBar.set_modified(True)
        return 'break'

    def _reconfigure_screen(self):
        resolutionIndex = int(prefs['resolution_index'])
        height, width = RESOLUTIONS[resolutionIndex]
        scale = height / DEFAULT_HEIGHT
        self._statusBar.set_font(scale)
        self._helpScreen.set_font(scale)
        self._footerBar.set_font(scale)
        self._editorWindow.configure(
            height=height,
            width=width,
        )
        self._sectionEditor.configure(
            spacing1=int(int(prefs['paragraph_spacing']) * scale),
            spacing2=int(int(prefs['line_spacing']) * scale),
            padx=int(int(prefs['margin_horizontal']) * scale),
            pady=int(int(prefs['margin_vertical']) * scale),
            font=(
                prefs['editor_font'],
                int(int(prefs['font_size_1']) * scale),
            ),
        )
        self._sectionEditor.configure_font(
            (
                prefs['editor_font'],
                int(int(prefs['font_size_1']) * scale),
            ),
        )

    def _reset_modified_flag(self, event=None):
        self._statusBar.set_modified(False)
        self._sectionEditor.edit_modified(False)

    def _save_project(self, event=None):
        self._sectionEditor.edit_modified(False)
        self._apply_changes()
        self._ctrl.save_project()
        self._statusBar.set_saved()

    def _set_wc_mode(self):
        if prefs['live_wordcount']:
            self.bind('<KeyRelease>', self._show_wordcount)
            self.unbind('<space>')
        else:
            self.unbind('<KeyRelease>')
            self.bind('<space>', self._freeze_wordcount)

    def _show_help_screen(self, event=None):
        if self._sectionEditor.winfo_manager():
            self._sectionEditor.pack_forget()
        self._helpScreen.pack(fill='x', side='top')
        self._sectionEditor.pack(fill='both', expand=True)
        prefs['show_help_screen'] = True
        return 'break'

    def _show_footer_bar(self, event=None):
        if self._sectionEditor.winfo_manager():
            self._sectionEditor.pack_forget()
        self._footerBar.pack(fill='x', side='bottom')
        self._sectionEditor.pack(fill='both', expand=True)
        prefs['show_footer_bar'] = True
        return 'break'

    def _show_wordcount(self, event=None, wc=None):
        if wc is None:
            wc = self.wordCounter.get_word_count(
                self._sectionEditor.get('1.0', 'end')
            )
        self._actualWordCount = wc
        diff = wc - self._initialWc
        text = f'{wc} {_("words")} ({diff} {_("new")})'
        self._statusBar.set_wordcount(text)

    def _split_section(self, event=None):
        if not self._ui.ask_yes_no(
            message=_('Move the text from the cursor position to the end into a new section?'),
            title=FEATURE,
            parent=self,
        ):
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self._sectionEditor.get_text(
                'insert',
                'end'
            ).strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            self._mdl.novel.sections[newId].viewpoint = (
                self._mdl.novel.sections[self._scId].viewpoint
            )

            self._load_next()
            self._askForConfirmation = False

    def _strong_emphasis(self, event=None):
        if self._sectionEditor.strong_emphasis():
            self._statusBar.set_modified(True)
        return 'break'

    def _to_lowercase(self, event=None):
        self._sectionEditor.to_lowercase()
        return 'break'

    def _to_uppercase(self, event=None):
        self._sectionEditor.to_uppercase()
        return 'break'

    def _toggle_case(self, event=None):
        self._sectionEditor.toggle_case()
        return 'break'

    def _toggle_help(self, event=None):
        if self._helpScreen.winfo_manager():
            self._hide_help_screen()
        else:
            self._show_help_screen()
        return 'break'

    def _toggle_display(self, event=None):
        if self._footerBar.winfo_manager():
            self._hide_footer_bar()
            self._statusBar.normal()
        else:
            self._show_footer_bar()
            self._statusBar.highlight()
        return 'break'

    def _update_modified_flag(self, event=None):
        if self._sectionEditor.edit_modified():
            self._statusBar.set_modified(True)
            if not prefs['live_wordcount']:
                self._freeze_wordcount()
        else:
            self._reset_modified_flag()



class WriterService(SubController):
    INI_FILENAME = 'writer.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        color_bg='gray15',
        color_button_bg='gray70',
        color_button_fg='gray15',
        color_desktop='gray30',
        color_fg='gray70',
        color_em='gray85',
        color_notes='red',
        color_shortcut='gray85',
        color_status_bg='gray70',
        color_status_fg='gray15',
        color_strong='gray85',
        editor_font=DEFAULT_FONT,
        font_size_1=12,
        line_spacing=7,
        paragraph_spacing=14,
        margin_horizontal=10,
        margin_vertical=10,
        resolution_index=1,
    )
    OPTIONS = dict(
        ask_for_confirmation=True,
        live_wordcount=False,
        show_footer_bar=True,
        show_help_screen=True,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

        make_scrollbar_style()

    def on_quit(self):

        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        self.configuration.write()

    def start_editor(self):
        if self._ctrl.isLocked:
            return

        if not self._mdl.prjFile:
            return

        if not self._mdl.prjFile.filePath:
            return

        if not self._mdl.novel.sections:
            return

        activeDocuments = self._active_documents()
        if activeDocuments:
            activeDocuments.insert(
                0,
                f"{_('Documents found that might be edited')}:"
            )
            self._ui.show_error(
                message=_('Editing not possible'),
                detail='\n- '.join(activeDocuments),
                title=FEATURE,
            )
            return

        self.writer = WriterView(self._mdl, self._ui, self._ctrl)

    def _active_documents(self):
        docTypes = {
            _('Editable manuscript'): f'{MANUSCRIPT_SUFFIX}.odt',
            _('Tagged manuscript for proofing'): f'{PROOF_SUFFIX}.odt',
        }
        activeDocs = []
        try:
            fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        except TypeError:
            pass
        else:
            for doc in docTypes:
                if os.path.isfile(f'{fileName}{docTypes[doc]}'):
                    activeDocs.append(doc)
        return activeDocs



class Plugin(PluginBase):
    VERSION = '5.1.0'
    API_VERSION = '5.53'
    DESCRIPTION = 'Distraction free editor'
    URL = 'https://github.com/peter88213/nv_writer'

    DTD_MAJOR_VERSION = 1
    DTD_MINOR_VERSION = 9

    def install(self, model, view, controller):
        """Extend the 'View' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        (
            novelibreDtdMajorVersion,
            novelibreDtdMinorVersion
        ) = model.nvService.get_novx_dtd_version()
        if (
            novelibreDtdMajorVersion != self.DTD_MAJOR_VERSION or
            novelibreDtdMinorVersion > self.DTD_MINOR_VERSION
        ):
            raise RuntimeError(
                'Outdated: Current novx file version not supported.'
            )

        super().install(model, view, controller)

        self.writerService = WriterService(model, view, controller)
        self._icon = self._get_icon('writer.png')

        self._ui.sectionMenu.add_separator()

        label = FEATURE
        self._ui.sectionMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionMenu.disableOnLock.append(label)

        self._ui.sectionContextMenu.add_separator()
        self._ui.sectionContextMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionContextMenu.disableOnLock.append(label)

        label = _('Distraction-free writing plugin Options')
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self._open_options_dialog,
        )

        label = _('Distraction-free writing plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=NvwriterHelp.open_help_page,
        )

        self._ui.toolbar.add_separator(),

        self._ui.toolbar.new_button(
            text=FEATURE,
            image=self._icon,
            command=self.start_editor,
            accelerator=KEYS.START_EDITOR[1],
        ).pack(side='left')

        self._ui.root.bind(KEYS.START_EDITOR[0], self.start_editor)

    def on_quit(self, event=None):
        self.writerService.on_quit()

    def start_editor(self, event=None):
        self.writerService.start_editor()
        return 'break'

    def _open_options_dialog(self):
        OptionsDialog(self._ui, self._icon)
