"""A "distraction free editor mode" plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_writer
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_writer',
        LOCALE_PATH, languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon

prefs = {}

BULLET = '* '
COMMENT_PREFIX = 'cmId'
FEATURE = _('Write in distraction free mode')
T_COMMENT = 'comment'
T_CREATOR = 'creator'
T_DATE = 'date'
T_EM = 'em'
T_H5 = 'h5'
T_H6 = 'h6'
T_H7 = 'h7'
T_H8 = 'h8'
T_H9 = 'h9'
T_LI = 'li'
T_NOTE = 'note'
T_SPAN = 'span'
T_STRONG = 'strong'
T_UL = 'ul'

import webbrowser


class NvwriterHelp:

    HELP_URL = 'https://peter88213.github.io/nv_writer/help/'

    @classmethod
    def open_help_page(cls, page='', event=None):
        webbrowser.open(f'{cls.HELP_URL}{page}')

from tkinter import ttk

import platform


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    BACK = ('<Alt-Left>', f'{_("Alt-Left")}')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    FORWARD = ('<Alt-Right>', f'{_("Alt-Right")}')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    NEXT = ('<Alt-Down>', f'{_("Alt-Down")}')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PREVIOUS = ('<Alt-Up>', f'{_("Alt-Up")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'
    RIGHT_CLICK = '<Button-3>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Alt-Shift-N>', 'Cmd-Alt-Shift-N')
    CHAPTER_LEVEL = ('<Command-Alt-c>', 'Cmd-Alt-C')
    COPY = ('<Command-c>', 'Cmd-C')
    CUT = ('<Command-x>', 'Cmd-X')
    DETACH_PROPERTIES = ('<Command-Alt-d>', 'Cmd-Alt-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PASTE = ('<Command-v>', 'Cmd-V')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    TOGGLE_PROPERTIES = ('<Command-Alt-t>', 'Cmd-Alt-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')


class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()

from abc import abstractmethod



class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, ui, **kw):
        tk.Toplevel.__init__(self, **kw)
        __, x, y = ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()



class OptionsDialog(ModalDialog):

    def __init__(self, view, icon, **kw):
        super().__init__(view, **kw)

        self.title(_('Distraction-free writing plugin Options'))
        self.iconphoto(False, icon)
        window = ttk.Frame(self)
        window.pack(
            fill='both',
        )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')
        ttk.Separator(
            window,
            orient='vertical',
        ).pack(fill='y', side='left')
        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', side='left')

        self._askForConfirmationVar = tk.BooleanVar(
            frame1,
            value=prefs['ask_for_confirmation'],
        )
        ttk.Label(
            frame1,
            text=_('Apply changes')
        ).pack(padx=5, pady=5, anchor='w')
        ttk.Checkbutton(
            frame1,
            text=_('Ask for confirmation'),
            variable=self._askForConfirmationVar,
            command=self._change_ask_for_confirmation,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(frame1, orient='horizontal').pack(fill='x')

        ttk.Label(
            frame1,
            text=_('Word count')
        ).pack(padx=5, pady=5, anchor='w')
        self._liveWordcountVar = tk.BooleanVar(
            frame1,
            value=prefs['live_wordcount'],
        )
        ttk.Checkbutton(
            frame1,
            text=_('Live update'),
            variable=self._liveWordcountVar,
            command=self._change_live_wc,
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Label(
            frame2,
            text=_('Coloring mode')
        ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy,
        ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help,
        ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], NvwriterHelp.open_help_page)

    def _change_live_wc(self):
        prefs['live_wordcount'] = self._liveWordcountVar.get()

    def _change_ask_for_confirmation(self):
        prefs['ask_for_confirmation'] = self._askForConfirmationVar.get()

    def _change_colors(self, *args, **kwargs):
        pass

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('options.html')




class GenericKeys:

    APPLY_CHANGES = ('<Control-s>', f'{_("Ctrl")}-S')
    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SCENE = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_HELP = ('<F1>', 'F1')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SPLIT_SCENE = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')
    START_EDITOR = ('<Control-w>', f'{_("Ctrl")}-W')
    TOGGLE_FOOTER_BAR = ('<Control-F1>', f'{_("Ctrl")}-F1')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')


class MacKeys(GenericKeys):

    APPLY_CHANGES = ('<Command-s>', 'Cmd-S')
    BOLD = ('<Command-b>', 'Cmd-B')
    CREATE_SCENE = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ITALIC = ('<Command-i>', 'Cmd-I')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SPLIT_SCENE = ('<Command-Alt-s>', 'Cmd-Alt-S')
    START_EDITOR = ('<Command-w>', 'Cmd-W')
    TOGGLE_FOOTER_BAR = ('<Command-F1>', 'Cmd-F1')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()

from pathlib import Path



ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

from tkinter import ttk


def make_scrollbar_styles(
    troughcolor='black',
    background='grey',
    arrowcolor='white',
):
    style = ttk.Style()

    for is_hori in (True, False):
        v = "Horizontal" if is_hori else "Vertical"
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.trough',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.thumb',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.leftarrow',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.rightarrow',
            'from',
            'default',
        )
        style.element_create(
            f'CustomScrollbarStyle.{v}.Scrollbar.grip',
            'from',
            'default',
        )
        style.layout(
            f'CustomScrollbarStyle.{v}.TScrollbar',
            [(f'CustomScrollbarStyle.{v}.Scrollbar.trough', {
                'children': [
                    (f'CustomScrollbarStyle.{v}.Scrollbar.thumb', {
                        'unit': '1',
                        'children': [(
                            f'CustomScrollbarStyle.{v}.Scrollbar.grip',
                            {'sticky': ''}
                        )],
                        'sticky': 'nswe'}
                     )
                ],
                'sticky': 'we' if is_hori else 'ns'}),
             ])
        style.configure(
            f'CustomScrollbarStyle.{v}.TScrollbar',
            troughcolor=troughcolor,
            background=background,
            arrowcolor=arrowcolor,
        )
    return (
        "CustomScrollbarStyle.Horizontal.TScrollbar",
        "CustomScrollbarStyle.Vertical.TScrollbar"
    )

from tkinter import ttk

import re
from tkinter import ttk



def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)


from xml import sax



class Comment:

    def __init__(self):
        self.creator = None
        self.date = None
        self.text = None

    def add_text(self, text, separator):
        if not self.text:
            self.text = text
        else:
            self.text = f'{self.text}{separator}{text}'

    def get_xml(self):
        text = self.text.replace('\n', '</p><p>')
        return(
            '<comment>'
            f'<creator>{self.creator}</creator>'
            f'<date>{self.date}</date>'
            f'<p>{text}</p>'
            '</comment>'
        )



class NovxParser(sax.ContentHandler):

    def __init__(self):
        super().__init__()

        self.textTag = ''
        self._taggedText = []
        self._tags = []
        self._spans = []
        self.comments = []
        self._heading = None
        self._list = None
        self._commentState = None

    def feed(self, xmlString):
        self._taggedText.clear()
        self._tags.clear()
        self._spans.clear()
        self.comments.clear()
        self._heading = False
        self._list = False
        self._commentState = None

        if xmlString:
            sax.parseString(f'<content>{xmlString}</content>', self)

    def characters(self, content):
        if self._commentState == T_CREATOR:
            self.comments[-1].creator = content
            return

        if self._commentState == T_DATE:
            self.comments[-1].date = content
            return

        if self._commentState == 'p':
            self.comments[-1].add_text(content, '\n')
            return

        if self._commentState is not None:
            print(self._commentState)
            return

        tag = [self.textTag]
        if self._tags:
            self._tags.reverse()
            tag.extend(self._tags)
        self._taggedText.append((content, tag))

    def endElement(self, name):
        if name == T_COMMENT:
            tag = (T_COMMENT, f'{COMMENT_PREFIX}:{len(self.comments)-1}')
            self._taggedText.append((self.comments[-1].text, tag))
            self._commentState = None
            return

        if name in (
            'p',
        ):
            self._spans.clear()
            self._tags.clear()
        if name in (
            T_EM,
            T_STRONG,
        ):
            self._tags.remove(name)
        elif name == T_SPAN:
            self._tags.remove(self._spans.pop())
        elif name in (
            T_H5,
            T_H6,
            T_H7,
            T_H8,
            T_H9,
        ):
            self._heading = False
        elif name == T_UL:
            self._list = False
        elif name == T_NOTE:
            self._note = False

    def get_result(self):
        return self._taggedText

    def startElement(self, name, attrs):
        if name == T_COMMENT:
            self.comments.append(Comment())
            self._commentState = name
            return

        if self._commentState is not None:
            self._commentState = name
            return

        attributes = []
        for attribute in attrs.items():
            attrKey, attrValue = attribute
            attributes.append(f'{attrKey}="{attrValue}"')
        suffix = ''
        if name in (
            'p',
        ):
            if self._taggedText and not self._list:
                suffix = '\n'
            if attributes:
                span = f"{name}_{'_'.join(attributes)}"
                self._spans.append(span)
                self._tags.append(span)
        elif name in (
            T_EM,
            T_STRONG,
        ):
            self._tags.append(name)
        elif name == T_SPAN:
            span = f"{name}_{'_'.join(attributes)}"
            self._spans.append(span)
            self._tags.append(span)
        elif name in (
            T_H5,
            T_H6,
            T_H7,
            T_H8,
            T_H9,
        ):
            self._heading = True
            self.headingTag = name
            suffix = '\n'
        elif name == T_UL:
            self._list = True
        elif name == T_NOTE:
            self._note = True
            suffix = '\n'
        elif name == T_LI:
            suffix = f'\n{BULLET}'
        if suffix:
            self._taggedText.append((suffix, ''))
from xml.sax.saxutils import escape



class TextParser():

    def __init__(self):
        self._paragraph = None
        self._list = None
        self._textlist = []
        self.comments = []
        self._commentIndex = None

    def reset(self):
        self._paragraph = False
        self._list = False
        self._textlist.clear()
        self._commentIndex = None

    def parse_triple(self, key, value, __):
        if key == 'text' and value:
            self.characters(value)
        elif key == 'tagon' and value:
            self.startElement(value)
        elif key == 'tagoff' and value:
            self.endElement(value)

    def characters(self, content):
        if self._commentIndex is not None:
            self.comments[self._commentIndex].add_text(content, '')
            return

        content = escape(content)
        content = strip_illegal_characters(content)
        if not self._paragraph:
            if content.startswith(BULLET):
                content = content.lstrip(BULLET)
                if not self._list:
                    self._textlist.append(f'<{T_UL}>')
                    self._list = True
                self._textlist.append(f'<{T_LI}>')
            elif self._list:
                self._textlist.append(f'</{T_UL}>')
                self._list = False
            self._textlist.append('<p>')
            self._paragraph = True
        if content.endswith('\n'):
            self._textlist.append(f'{content.rstrip()}</p>')
            self._paragraph = False
            if self._list:
                self._textlist.append(f'</{T_LI}>')
        else:
            self._textlist.append(content)

    def endElement(self, name):
        if name in (T_EM, T_STRONG):
            self._textlist.append(f'</{name}>')
        elif name.startswith(T_SPAN):
            self._textlist.append(f'</{T_SPAN}>')
        elif name.startswith(COMMENT_PREFIX):
            self._textlist.append(self.comments[self._commentIndex].get_xml())
            self._commentIndex = None

    def get_result(self):
        if self._list:
            self._textlist.append(f'</{T_UL}>')
        return ''.join(self._textlist)

    def startElement(self, name):
        if name.startswith(COMMENT_PREFIX):
            self._commentIndex = int(name.split(':')[1])
            self.comments[self._commentIndex].text = ''
            return

        if name.startswith('p'):
            self._textlist.append(f'<{name.replace("_", " ")}>')
        elif not self._paragraph:
            self._textlist.append('<p>')
        self._paragraph = True
        if name in (T_EM, T_STRONG):
            self._textlist.append(f'<{name}>')
        elif name.startswith(T_SPAN):
            self._textlist.append(f'<{name.replace("_", " ")}>')

import xml.etree.ElementTree as ET


class EditorBox(tk.Text):

    def __init__(
        self,
        master=None,
        vstyle=None,
        color_highlight='grey',
        **kw,
    ):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        if vstyle is not None:
            self.vbar.configure(style=vstyle)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self._novxParser = NovxParser()

        self._textParser = TextParser()

        self.tag_configure(
            T_EM,
            foreground=color_highlight,
        )
        self.tag_configure(
            T_STRONG,
            foreground=color_highlight,
        )
        self.tag_configure(
            T_COMMENT,
            background=color_highlight,
            foreground=kw['bg'],
        )
        self.tag_configure(
            T_NOTE,
            background=color_highlight,
        )

    def clear(self):
        self.delete('1.0', 'end')

    def get_text(self, start='1.0', end='end'):
        self._textParser.reset()
        self._textParser.comments = self._novxParser.comments
        self.dump(start, end, command=self._textParser.parse_triple)
        return self._textParser.get_result()

    def set_text(self, text):
        if text:
            self._novxParser.feed(text)
            taggedText = self._novxParser.get_result()
        else:
            taggedText = []

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index

        self.edit_reset()
        self.mark_set('insert', f'1.0')

    def emphasis(self, event=None):
        self._set_format(tag=T_EM)
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag=T_STRONG)
        return 'break'

    def plain(self, event=None):
        self._set_format()
        return 'break'

    def _get_tags(self, start, end):
        index = start
        tags = []
        while self.compare(index, '<=', end):
            tags.extend(self.tag_names(index))
            index = self.index(f'{index}+1c')
        return set(tags)

    def _replace_selected(self, text, tag):
        self.mark_set(tk.INSERT, tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index(tk.INSERT)
        self.insert(tk.INSERT, text, tag)
        selLast = self.index(tk.INSERT)
        self.tag_add(tk.SEL, selFirst, selLast)

    def _set_format(self, event=None, tag=''):
        if self.tag_ranges(tk.SEL):
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            currentTags = self._get_tags(tk.SEL_FIRST, tk.SEL_LAST)
            if tag in currentTags:
                tag = ''
            self._replace_selected(text, tag)



class FooterBar(tk.Frame):

    def __init__(self, parent, prefs, **kw):
        super().__init__(
            parent,
            background=prefs['color_bg'],
            **kw,
        )
        self._prefs = prefs


        closeButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Close'),
            padx=4,
            pady=2,
        )
        closeButton.pack(
            side='right',
        )
        closeButton.bind('<Button-1>', self._event('<<on_quit>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.QUIT_PROGRAM[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

        applyButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Apply changes'),
            padx=4,
            pady=2,
        )
        applyButton.pack(
            side='right',
        )
        applyButton.bind('<Button-1>', self._event('<<apply_changes>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.APPLY_CHANGES[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

        previousButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Previous'),
            padx=4,
            pady=2,
        )
        previousButton.pack(
            side='right',
        )
        previousButton.bind('<Button-1>', self._event('<<load_prev>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.PREVIOUS[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

        nextButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Next'),
            padx=4,
            pady=2,
        )
        nextButton.pack(
            side='right',
        )
        nextButton.bind('<Button-1>', self._event('<<load_next>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.NEXT[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

        applyButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Split at cursor position'),
            padx=4,
            pady=2,
        )
        applyButton.pack(
            side='right',
        )
        applyButton.bind('<Button-1>', self._event('<<split_section>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.SPLIT_SCENE[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

        applyButton = tk.Label(
            self,
            background=prefs['color_fg'],
            foreground=prefs['color_bg'],
            text=_('Create section'),
            padx=4,
            pady=2,
        )
        applyButton.pack(
            side='right',
        )
        applyButton.bind('<Button-1>', self._event('<<new_section>>'))

        tk.Label(
            self,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text=KEYS.CREATE_SCENE[1],
        ).pack(
            padx=(10, 2),
            pady=2,
            side='right',
        )

    def show(self, event=None):
        self.pack(fill='x')
        self._prefs['show_footer_bar'] = True
        return 'break'

    def hide(self, event=None):
        self.pack_forget()
        self._prefs['show_footer_bar'] = False
        return 'break'

    def toggle(self, event=None):
        if self.winfo_manager():
            self.hide()
        else:
            self.show()
        return 'break'

    def _event(self, sequence):

        def callback(*_):
            root = self.master.winfo_toplevel()
            root.event_generate(sequence)

        return callback


class WriterView(ModalDialog):

    def __init__(
        self,
        model,
        view,
        controller,
    ):
        view.root.iconify()
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        super().__init__(view, bg=prefs['color_desktop'])

        self._section = None
        self._scId = None
        self._isModified = None
        self.wordCounter = self._mdl.nvService.get_word_counter()

        self.attributes('-fullscreen', True)
        self.update_idletasks()
        screenwidth = self.winfo_screenwidth()
        editorWidth = int(prefs['editor_width'])
        if editorWidth > screenwidth:
            editorWidth = screenwidth
        editorWindow = ttk.Frame(
            self,
            width=editorWidth,
        )
        editorWindow.pack(
            expand=True,
        )

        self._statusBar = tk.Frame(
            editorWindow,
            background=prefs['color_bg'],
        )
        self._statusBar.pack(
            fill='x',
        )


        ttk.Style().configure(
            'CustomScrollbarStyle.Vertical.TScrollbar',
            troughcolor=prefs['color_desktop'],
            background=prefs['color_bg'],
        )

        self._sectionEditor = EditorBox(
            editorWindow,
            vstyle='CustomScrollbarStyle.Vertical.TScrollbar',
            color_highlight=prefs['color_highlight'],
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=prefs['paragraph_spacing'],
            spacing2=prefs['line_spacing'],
            maxundo=-1,
            padx=prefs['margin_x'],
            pady=prefs['margin_y'],
            fg=prefs['color_fg'],
            bg=prefs['color_bg'],
            insertbackground=prefs['color_fg'],
            font=(
                prefs['font_family'],
                prefs['font_size'],
            ),
            height=prefs['editor_height'],
        )
        self._sectionEditor.pack(expand=True, fill='both')

        self._footerBar = FooterBar(
            editorWindow,
            prefs,
        )
        if prefs['show_footer_bar']:
            self._footerBar.show()

        self._breadcrumbs = tk.Label(
            self._statusBar,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._breadcrumbs.pack(
            side='left',
        )

        self._wordCount = tk.Label(
            self._statusBar,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._wordCount.pack(
            side='left',
        )

        self._modificationIndicator = tk.Label(
            self._statusBar,
            background=prefs['color_bg'],
            foreground=prefs['color_fg'],
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._modificationIndicator.pack(
            side='left',
        )

        self._sectionEditor.bind(
            KEYS.PREVIOUS[0],
            self._load_prev,
        )
        self._sectionEditor.bind(
            KEYS.NEXT[0],
            self._load_next,
        )
        self.bind(
            KEYS.OPEN_HELP[0],
            self._open_help
        )
        self._sectionEditor.bind(
            KEYS.QUIT_PROGRAM[0],
            self.on_quit
        )
        self._sectionEditor.bind(
            KEYS.APPLY_CHANGES[0],
            self._apply_changes
        )
        self._sectionEditor.bind(
            KEYS.UPDATE_WORDCOUNT[0],
            self._show_wordcount
        )
        self._sectionEditor.bind(
         KEYS.SPLIT_SCENE[0],
         self._split_section
        )
        self._sectionEditor.bind(
            KEYS.CREATE_SCENE[0],
            self._create_section
        )
        self._sectionEditor.bind(
            KEYS.ITALIC[0],
            self._sectionEditor.emphasis
        )
        self._sectionEditor.bind(
            KEYS.BOLD[0],
            self._sectionEditor.strong_emphasis
        )
        self._sectionEditor.bind(
            KEYS.PLAIN[0],
            self._sectionEditor.plain
        )
        self._sectionEditor.bind(
            KEYS.TOGGLE_FOOTER_BAR[0],
            self._footerBar.toggle
        )

        event_callbacks = {
            '<<load_next>>': self._load_next,
            '<<on_quit>>': self.on_quit,
            '<<load_prev>>': self._load_prev,
            '<<apply_changes>>': self._apply_changes,
            '<<split_section>>': self._split_section,
            '<<new_section>>': self._create_section,
        }
        for sequence, callback in event_callbacks.items():
            self.bind(sequence, callback)

        self._set_wc_mode()
        self._askForConfirmation = prefs['ask_for_confirmation']

        self._load_section(self._ui.selectedNode)
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        self._ui.root.deiconify()
        self._ui.root.lift()
        self.destroy()

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._section.sectionContent = sectionText

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if self._confirm(message=_('Apply section changes?')):
                    self._section.sectionContent = sectionText
        return True

    def _confirm(self, message):
        if self._askForConfirmation:
            return self._ui.ask_yes_no(
                message=message,
                title=FEATURE,
                parent=self,
            )
        else:
            return True

    def _create_section(self, event=None):
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        self._askForConfirmation = False
        return newId

    def _is_editable(self, scId):
        if not scId or not scId.startswith(SECTION_PREFIX):
            return False

        return self._mdl.novel.sections[scId].scType == 0

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        while nextNode and not self._is_editable(nextNode):
            nextNode = self._ui.tv.next_node(nextNode)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self._scId = nextNode
            self._load_section(self._scId)

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        while prevNode and not self._is_editable(prevNode):
            prevNode = self._ui.tv.prev_node(prevNode)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self._scId = prevNode
            self._load_section(self._scId)

    def _load_section(self, scId=None):
        self._sectionEditor.unbind("<<Modified>>")
        finished = False
        if not self._is_editable(scId):
            for chId in self._mdl.novel.tree.get_children(CH_ROOT):
                for scId in self._mdl.novel.tree.get_children(chId):
                    if self._is_editable(scId):
                        finished = True
                        break
                if finished:
                    break
        else:
            finished = True
        if not finished:
            return

        self._section = self._mdl.novel.sections[scId]
        self._sectionEditor.clear()
        self._sectionEditor.set_text(
            self._section.sectionContent
        )
        self._scId = scId
        chId = self._mdl.novel.tree.parent(self._scId)

        self._breadcrumbs['text'] = (
            f'{self._mdl.novel.title} | '
            f'{self._mdl.novel.chapters[chId].title} | '
            f'{self._section.title}'
        )
        self._initialWc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        self._show_wordcount()
        self._reset_modified_flag()
        self._sectionEditor.bind(
            "<<Modified>>",
            self._set_modified_flag
        )
        self._askForConfirmation = prefs['ask_for_confirmation']

    def _open_help(self, event=None):
        NvwriterHelp.open_help_page('operation.html')

    def _reset_modified_flag(self, event=None):
        self._isModified = False
        self._modificationIndicator.config(text='')
        self._sectionEditor.edit_modified(False)

    def _set_modified_flag(self, event=None):
        if self._sectionEditor.edit_modified():
            self._isModified = True
            self._modificationIndicator.config(text=_('Modified'))
        else:
            self._reset_modified_flag()

    def _set_wc_mode(self):
        if prefs['live_wordcount']:
            self.bind('<KeyRelease>', self._show_wordcount)
        else:
            self.unbind('<KeyRelease>')

    def _show_wordcount(self, event=None):
        wc = self.wordCounter.get_word_count(
            self._sectionEditor.get('1.0', 'end')
        )
        diff = wc - self._initialWc
        self._wordCount.config(text=f'{wc} {_("words")} ({diff} {_("new")})')

    def _split_section(self, event=None):
        if not self._confirm(
            message=_('Move the text from the cursor position to the end into a new section?'),
        ):
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self._sectionEditor.get_text(
                'insert',
                'end'
            ).strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            self._mdl.novel.sections[newId].viewpoint = (
                self._mdl.novel.sections[self._scId].viewpoint
            )

            self._load_next()
            self._askForConfirmation = False



class WriterService(SubController):
    INI_FILENAME = 'writer.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        editor_height=15,
        editor_width=800,
        color_highlight='green2',
        color_bg='gray20',
        color_fg='green3',
        color_desktop='gray30',
        font_family='Courier',
        font_size=13,
        line_spacing=7,
        paragraph_spacing=21,
        margin_x=40,
        margin_y=20,
    )
    OPTIONS = dict(
        live_wordcount=False,
        show_footer_bar=False,
        ask_for_confirmation=True,
    )

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

        make_scrollbar_styles()

    def on_quit(self):

        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        self.configuration.write()

    def start_editor(self):
        if self._ctrl.isLocked:
            return

        if not self._mdl.prjFile:
            return

        activeDocuments = self._active_documents()
        if activeDocuments:
            activeDocuments.insert(
                0,
                f"{_('Documents found that might be edited')}:"
            )
            self._ui.show_error(
                message=_('Editing not possible'),
                detail='\n- '.join(activeDocuments),
                title=FEATURE,
            )
            return

        self.writer = WriterView(self._mdl, self._ui, self._ctrl)

    def _active_documents(self):
        docTypes = {
            _('Editable manuscript'): f'{MANUSCRIPT_SUFFIX}.odt',
            _('Tagged manuscript for proofing'): f'{PROOF_SUFFIX}.odt',
        }
        fileName, __ = os.path.splitext(self._mdl.prjFile.filePath)
        activeDocs = []
        for doc in docTypes:
            if os.path.isfile(f'{fileName}{docTypes[doc]}'):
                activeDocs.append(doc)
        return activeDocs



class Plugin(PluginBase):
    VERSION = '0.5.0'
    API_VERSION = '5.52'
    DESCRIPTION = 'Distraction free editor'
    URL = 'https://github.com/peter88213/nv_writer'

    DTD_MAJOR_VERSION = 1
    DTD_MINOR_VERSION = 9

    def install(self, model, view, controller):
        """Extend the 'View' menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        (
            novelibreDtdMajorVersion,
            novelibreDtdMinorVersion
        ) = model.nvService.get_novx_dtd_version()
        if (
            novelibreDtdMajorVersion != self.DTD_MAJOR_VERSION or
            novelibreDtdMinorVersion > self.DTD_MINOR_VERSION
        ):
            raise RuntimeError(
                'Outdated: Current novx file version not supported.'
            )

        super().install(model, view, controller)

        self.writerService = WriterService(model, view, controller)
        self._icon = self._get_icon('writer.png')

        self._ui.sectionMenu.add_separator()

        label = FEATURE
        self._ui.sectionMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionMenu.disableOnLock.append(label)

        self._ui.sectionContextMenu.add_separator()
        self._ui.sectionContextMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self.start_editor,
        )
        self._ui.sectionContextMenu.disableOnLock.append(label)

        label = _('Distraction-free writing plugin Options')
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self._open_options_dialog,
        )

        label = _('Distraction-free writing plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=NvwriterHelp.open_help_page,
        )

        self._ui.root.bind(KEYS.START_EDITOR[0], self.start_editor)

    def on_quit(self, event=None):
        self.writerService.on_quit()

    def start_editor(self, event=None):
        self.writerService.start_editor()
        return 'break'

    def _open_options_dialog(self):
        OptionsDialog(self._ui, self._icon)
